@echo off
setlocal
set "GT=C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag"
if not exist "%GT%\Gorilla Tag_Data\Managed\Assembly-CSharp.dll" (
  echo Gorilla Tag was not found at:
  echo %GT%
  echo.
  echo Edit GT in BUILD.bat to your Gorilla Tag folder, then run this again.
  pause
  exit /b 1
)

if exist "obj" rmdir /S /Q "obj"
if exist "bin" rmdir /S /Q "bin"

echo Building HeySiri v1.4 for current Gorilla Tag / Unity 6...
dotnet build HeySiri.csproj -c Release -p:GorillaTagDir="%GT%"
if errorlevel 1 (
  echo.
  echo Build failed. Read the error above.
  pause
  exit /b 1
)

set "DEST=%GT%\BepInEx\plugins\HeySiri"
if not exist "%DEST%" mkdir "%DEST%"

rem Remove old HeySiri DLL copies anywhere under plugins so BepInEx cannot load two versions.
for /R "%GT%\BepInEx\plugins" %%F in (HeySiri.dll) do @if exist "%%F" del /Q "%%F"

copy /Y "bin\Release\netstandard2.1\HeySiri.dll" "%DEST%\HeySiri.dll" >nul

echo.
echo Built: bin\Release\netstandard2.1\HeySiri.dll
echo Installed to: %DEST%
echo.
echo IMPORTANT: keep only this newest HeySiri.dll; remove any other duplicate copies.
pause
