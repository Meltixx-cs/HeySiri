using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.InputSystem;

namespace HeySiri;

internal static class InputBridge
{
    private static readonly BindingFlags InstanceFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    private static readonly BindingFlags StaticFlags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

    private static Type _pollerType;
    private static object _poller;
    private static bool _previousRecall;

    public static float GetGrip(bool right)
    {
        object poller = GetPoller();
        if (poller == null)
            return 0f;

        string[] names = right
            ? new[] { "rightControllerGripFloat", "rightGripFloat", "rightGrip", "rightControllerGrip" }
            : new[] { "leftControllerGripFloat", "leftGripFloat", "leftGrip", "leftControllerGrip" };

        foreach (string name in names)
        {
            object value = GetMemberValue(poller, name);
            if (value is float f) return f;
            if (value is double d) return (float)d;
            if (value is bool b) return b ? 1f : 0f;
        }

        return 0f;
    }

    public static bool RecallPressedThisFrame()
    {
        bool current = false;

        object poller = GetPoller();
        if (poller != null)
        {
            string[] names =
            {
                "rightControllerSecondaryButton",
                "rightSecondaryButton",
                "rightControllerSecondary",
                "rightSecondary"
            };

            foreach (string name in names)
            {
                object value = GetMemberValue(poller, name);
                if (value is bool b)
                {
                    current = b;
                    break;
                }
                if (value is float f)
                {
                    current = f > 0.5f;
                    break;
                }
            }
        }

        if (Keyboard.current != null && Keyboard.current.bKey.isPressed)
            current = true;

        bool down = current && !_previousRecall;
        _previousRecall = current;
        return down;
    }

    public static bool ManualWakePressedThisFrame()
    {
        return Keyboard.current != null && Keyboard.current.hKey.wasPressedThisFrame;
    }

    public static bool TogglePcPanelPressedThisFrame()
    {
        return Keyboard.current != null && Keyboard.current.f2Key.wasPressedThisFrame;
    }

    public static bool IsDesktopRightMousePressedThisFrame()
    {
        return Mouse.current != null && Mouse.current.rightButton.wasPressedThisFrame;
    }

    public static bool IsDesktopRightMouseHeld()
    {
        return Mouse.current != null && Mouse.current.rightButton.isPressed;
    }

    public static bool IsDesktopRightMouseReleasedThisFrame()
    {
        return Mouse.current != null && Mouse.current.rightButton.wasReleasedThisFrame;
    }

    public static Vector2 GetMousePosition()
    {
        return Mouse.current != null ? Mouse.current.position.ReadValue() : Vector2.zero;
    }

    public static bool IsLikelyVr(Camera camera)
    {
        if (camera == null)
            return false;

        try
        {
            if (camera.stereoEnabled)
                return true;
        }
        catch { }

        // A live controller poller with meaningful grip state is another useful signal.
        return GetPoller() != null && (GetHand(false) != null || GetHand(true) != null) && camera.name.IndexOf("Main Camera", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    public static Transform GetHand(bool right)
    {
        try
        {
            GorillaTagger tagger = GorillaTagger.Instance;
            if (tagger != null)
            {
                string[] names = right
                    ? new[] { "rightHandTransform", "rightHand", "rightControllerTransform" }
                    : new[] { "leftHandTransform", "leftHand", "leftControllerTransform" };

                foreach (string name in names)
                {
                    object value = GetMemberValue(tagger, name);
                    if (value is Transform t) return t;
                    if (value is Component c) return c.transform;
                    if (value is GameObject g) return g.transform;
                }
            }
        }
        catch
        {
            // Fall through to name-based lookup.
        }

        string[] paths = right
            ? new[]
            {
                "GorillaPlayer/TurnParent/RightHand Controller",
                "RightHand Controller",
                "RightHand",
                "Right Controller"
            }
            : new[]
            {
                "GorillaPlayer/TurnParent/LeftHand Controller",
                "LeftHand Controller",
                "LeftHand",
                "Left Controller"
            };

        foreach (string path in paths)
        {
            GameObject go = GameObject.Find(path);
            if (go != null) return go.transform;
        }

        return null;
    }

    public static Camera GetHeadCamera()
    {
        // IMPORTANT: Camera.main can resolve to Gorilla Tag's spectator/mirror camera on PC.
        // Prefer the player's real head camera first so the orb cannot spawn inside the gorilla body.
        string[] exactPaths =
        {
            "GorillaPlayer/TurnParent/Main Camera",
            "GorillaPlayer/TurnParent/VR Camera",
            "GorillaPlayer/Main Camera"
        };

        foreach (string path in exactPaths)
        {
            GameObject go = GameObject.Find(path);
            if (go == null) continue;
            Camera camera = go.GetComponent<Camera>();
            if (IsUsablePlayerCamera(camera))
                return camera;
        }

        // Search enabled cameras and strongly prefer names that look like the actual player eye.
        Camera[] cameras = Camera.allCameras;
        Camera best = null;
        int bestScore = int.MinValue;
        for (int i = 0; i < cameras.Length; i++)
        {
            Camera camera = cameras[i];
            if (!IsUsablePlayerCamera(camera))
                continue;

            string n = camera.name ?? string.Empty;
            int score = 0;
            if (n.IndexOf("main camera", StringComparison.OrdinalIgnoreCase) >= 0) score += 100;
            if (n.IndexOf("vr", StringComparison.OrdinalIgnoreCase) >= 0) score += 40;
            if (n.IndexOf("head", StringComparison.OrdinalIgnoreCase) >= 0) score += 30;
            if (camera.stereoEnabled) score += 25;
            if (n.IndexOf("spectator", StringComparison.OrdinalIgnoreCase) >= 0) score -= 200;
            if (n.IndexOf("mirror", StringComparison.OrdinalIgnoreCase) >= 0) score -= 200;
            if (n.IndexOf("shoulder", StringComparison.OrdinalIgnoreCase) >= 0) score -= 200;

            if (score > bestScore)
            {
                bestScore = score;
                best = camera;
            }
        }

        if (best != null)
            return best;

        Camera main = Camera.main;
        return IsUsablePlayerCamera(main) ? main : null;
    }

    private static bool IsUsablePlayerCamera(Camera camera)
    {
        if (camera == null || !camera.isActiveAndEnabled || camera.gameObject == null || !camera.gameObject.activeInHierarchy)
            return false;

        string n = camera.name ?? string.Empty;
        if (n.IndexOf("spectator", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        if (n.IndexOf("mirror", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        if (n.IndexOf("shoulder", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        if (n.IndexOf("verityeye", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        if (n.IndexOf("heysiri", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        return true;
    }

    private static object GetPoller()
    {
        if (_poller != null)
            return _poller;

        try
        {
            if (_pollerType == null)
                _pollerType = typeof(GorillaTagger).Assembly.GetType("ControllerInputPoller");

            if (_pollerType == null)
                return null;

            foreach (string name in new[] { "instance", "Instance" })
            {
                FieldInfo field = _pollerType.GetField(name, StaticFlags);
                if (field != null)
                {
                    _poller = field.GetValue(null);
                    if (_poller != null) return _poller;
                }

                PropertyInfo property = _pollerType.GetProperty(name, StaticFlags);
                if (property != null)
                {
                    _poller = property.GetValue(null, null);
                    if (_poller != null) return _poller;
                }
            }
        }
        catch
        {
            return null;
        }

        return null;
    }

    private static object GetMemberValue(object target, string name)
    {
        if (target == null) return null;
        Type type = target.GetType();

        try
        {
            FieldInfo field = type.GetField(name, InstanceFlags);
            if (field != null) return field.GetValue(target);

            PropertyInfo property = type.GetProperty(name, InstanceFlags);
            if (property != null && property.GetIndexParameters().Length == 0)
                return property.GetValue(target, null);
        }
        catch
        {
            // Ignore version-specific reflection failures.
        }

        return null;
    }
}
