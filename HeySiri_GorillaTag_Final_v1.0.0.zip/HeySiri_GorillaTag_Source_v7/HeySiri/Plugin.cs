using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;
using UnityEngine.Networking;
using Object = UnityEngine.Object;

namespace HeySiri;

[BepInPlugin(PluginInfo.Guid, PluginInfo.Name, PluginInfo.Version)]
public sealed class Plugin : BaseUnityPlugin
{
    private enum SiriMode
    {
        Normal,
        Evil,
        Rizzy
    }

    private sealed class ChatMessage
    {
        public string role;
        public string content;
    }

    public static Plugin Instance { get; private set; }

    private readonly List<ChatMessage> _history = new List<ChatMessage>();
    private readonly System.Random _random = new System.Random();

    private SpeechBridge _speechBridge;
    private Coroutine _speechRestart;
    private bool _stoppingSpeech;
    private float _restartDelay = 1f;
    private float _nextSpeechHealthCheck;
    private float _listenUntil;
    private float _ignoreSpeechUntil;
    private float _lastHeardAt = -10f;
    private string _lastHeard = string.Empty;
    private bool _processing;
    private bool _isSpeaking;
    private bool _muted;
    private readonly Queue<string> _queuedMessages = new Queue<string>();
    private float _reactionCooldownUntil;
    private float _autoSleepAt;
    private int _throwStreak;
    private float _lastThrowAt = -30f;

    private SiriOrbController _orb;

    private ConfigEntry<bool> _enabled;
    private ConfigEntry<string> _wakePhrase;
    private ConfigEntry<float> _listenWindow;
    private ConfigEntry<bool> _continuousConversation;
    private ConfigEntry<float> _followUpListenSeconds;
    private ConfigEntry<bool> _appearOnlyWhenAwake;
    private ConfigEntry<float> _autoSleepSeconds;
    private ConfigEntry<bool> _speechTextEnabled;

    private ConfigEntry<float> _orbScale;
    private ConfigEntry<float> _headDistance;
    private ConfigEntry<float> _screenX;
    private ConfigEntry<float> _screenY;
    private ConfigEntry<float> _followSmooth;
    private ConfigEntry<float> _grabDistance;
    private ConfigEntry<float> _throwMultiplier;
    private ConfigEntry<bool> _throwReactions;
    private ConfigEntry<bool> _profanityReactions;

    private ConfigEntry<string> _groqApiKey;
    private ConfigEntry<string> _groqModel;
    private ConfigEntry<string> _groqVisionModel;
    private ConfigEntry<bool> _enableVision;
    private ConfigEntry<string> _systemPrompt;
    private ConfigEntry<int> _historyMessages;
    private ConfigEntry<int> _maxReplyTokens;
    private ConfigEntry<string> _siriMode;

    private ConfigEntry<string> _fishApiKey;
    private ConfigEntry<string> _fishReferenceId;
    private ConfigEntry<string> _windowsVoiceContains;
    private ConfigEntry<int> _windowsVoiceRate;
    private ConfigEntry<int> _windowsVoiceVolume;
    private ConfigEntry<int> _windowsVoicePitchPercent;
    private ConfigEntry<int> _speechChunkCharacters;
    private ConfigEntry<int> _speechRetryCount;
    private ConfigEntry<float> _speechGapSeconds;

    private bool _showDesktopSpeechWarning;
    private bool _showPcPanel;
    private string _pcInput = string.Empty;
    private string _pcStatus = "Starting...";
    private CursorLockMode _previousCursorLock;
    private bool _previousCursorVisible;
    private bool _cursorCaptured;
    private float _panelAnim;

    private Texture2D _panelGradient;
    private Texture2D _panelShadow;
    private Texture2D _buttonTex;
    private Texture2D _buttonHoverTex;
    private Texture2D _fieldTex;
    private Texture2D _cyanTex;
    private Texture2D _siriBadgeTex;
    private GUIStyle _titleStyle;
    private GUIStyle _subtitleStyle;
    private GUIStyle _statusStyle;
    private GUIStyle _labelStyle;
    private GUIStyle _fieldStyle;
    private GUIStyle _buttonStyle;
    private GUIStyle _smallButtonStyle;

    private const float MaxRestartDelay = 30f;

    private void Awake()
    {
        Instance = this;

        _enabled = Config.Bind("General", "Enabled", true, "Enable HeySiri.");
        _wakePhrase = Config.Bind("General", "WakePhrase", "hey siri", "Phrase that wakes Siri.");
        _listenWindow = Config.Bind("General", "ListenWindowSeconds", 11f, "How long Siri listens after the wake phrase.");
        _continuousConversation = Config.Bind("General", "ContinuousConversation", true, "After answering, briefly keep listening so you can continue without saying Hey Siri again.");
        _followUpListenSeconds = Config.Bind("General", "FollowUpListenSeconds", 10f, "Follow-up listening window after Siri finishes talking.");
        _appearOnlyWhenAwake = Config.Bind("General", "AppearOnlyWhenAwake", true, "If true, Siri fades in when awakened and fades away when idle.");
        _autoSleepSeconds = Config.Bind("General", "AutoSleepSeconds", 14f, "How long Siri stays visible after a conversation ends when AppearOnlyWhenAwake is enabled.");
        _speechTextEnabled = Config.Bind("General", "SpeechTextEnabled", true, "Show text bubbles/subtitles for Siri lines.");

        _orbScale = Config.Bind("Orb", "Scale", 0.13f, "Overall Siri orb size.");
        _headDistance = Config.Bind("Orb", "DistanceFromHead", 0.92f, "Distance of docked Siri from the player camera.");
        _screenX = Config.Bind("Orb", "ScreenX", 0.83f, "Docked horizontal viewport position.");
        _screenY = Config.Bind("Orb", "ScreenY", 0.75f, "Docked vertical viewport position.");
        _followSmooth = Config.Bind("Orb", "HeadFollowSmooth", 22f, "How quickly the orb follows the player camera.");
        _grabDistance = Config.Bind("Orb", "GrabDistance", 0.22f, "How close your hand needs to be before grip can grab Siri.");
        _throwMultiplier = Config.Bind("Orb", "ThrowMultiplier", 1.45f, "Throw velocity multiplier.");
        _throwReactions = Config.Bind("Orb", "ThrowReactions", true, "Siri reacts when thrown or smacked into something.");
        _profanityReactions = Config.Bind("Orb", "ProfanityReactions", true, "Allow occasional stronger throw reactions such as 'fuck off'.");

        _groqApiKey = Config.Bind("AI", "GroqApiKey", string.Empty, "Required for AI replies.");
        _groqModel = Config.Bind("AI", "GroqModel", "openai/gpt-oss-120b", "Groq chat model.");
        _groqVisionModel = Config.Bind("AI", "GroqVisionModel", "qwen/qwen3.8-27b", "Groq vision model used when EnableVision=true.");
        _enableVision = Config.Bind("AI", "EnableVision", false, "If enabled, sends a screenshot of the game view with each request.");
        _historyMessages = Config.Bind("AI", "HistoryMessages", 30, "Maximum recent user/assistant messages kept for conversation memory.");
        _maxReplyTokens = Config.Bind("AI", "MaxReplyTokens", 650, "Maximum completion tokens. Higher values let Siri give longer answers.");
        _siriMode = Config.Bind("AI", "SiriMode", "Normal", "Siri personality mode: Normal, Evil, or Rizzy.");
        _systemPrompt = Config.Bind(
            "AI",
            "SystemPrompt",
            "You are Siri, an unofficial in-game female voice assistant for Gorilla Tag. Speak like a real person: warm, quick, expressive, a little witty, and never robotic. Answer what the user actually said, remember recent context, and use contractions and natural spoken phrasing. Casual answers should usually be 3-7 sentences, but be shorter when a short answer is clearly better and go longer when the user asks for detail. Do not say 'As an AI', do not constantly explain what you are, and do not end every answer with a generic offer to help. Light teasing is fine when it fits. Do not claim to be Apple's official Siri or imply Apple made this mod. Use plain text that sounds good when read aloud.",
            "Personality prompt sent to Groq.");

        _fishApiKey = Config.Bind("Voice", "FishAudioApiKey", string.Empty, "Optional Fish Audio API key.");
        _fishReferenceId = Config.Bind("Voice", "FishReferenceId", string.Empty, "Optional Fish Audio voice reference ID that you have permission to use.");
        _windowsVoiceContains = Config.Bind("Voice", "WindowsVoiceContains", "Zira", "Preferred installed Windows female voice name fragment. Zira is a common default.");
        _windowsVoiceRate = Config.Bind("Voice", "WindowsVoiceRate", -1, "Windows TTS base rate from -10 to 10. A slightly slower default is easier to understand in-game.");
        _windowsVoiceVolume = Config.Bind("Voice", "WindowsVoiceVolume", 100, "Windows TTS volume from 0 to 100.");
        _windowsVoicePitchPercent = Config.Bind("Voice", "WindowsVoicePitchPercent", 3, "Small SSML pitch lift for a brighter female voice without making it sound synthetic.");
        _speechChunkCharacters = Config.Bind("Voice", "SpeechChunkCharacters", 150, "Long replies are split into smaller TTS chunks so speech is less likely to stop early.");
        _speechRetryCount = Config.Bind("Voice", "SpeechRetryCount", 1, "How many times a failed speech chunk is retried.");
        _speechGapSeconds = Config.Bind("Voice", "SpeechGapSeconds", 0.08f, "Short pause between spoken chunks.");

        Logger.LogInfo("HeySiri v" + PluginInfo.Version + " loaded.");
    }

    private void Start()
    {
        if (!_enabled.Value)
        {
            Logger.LogInfo("HeySiri is disabled in config.");
            return;
        }

        EnsureOrb();
        SetupSpeechRecognition();
        Logger.LogInfo("HeySiri ready. Say 'Hey Siri', press H to wake, or press F2 for the PC panel.");
    }

    private void Update()
    {
        if (!_enabled.Value) return;

        PumpSpeechRecognition();

        if (InputBridge.ManualWakePressedThisFrame()) ManualWake();
        if (InputBridge.TogglePcPanelPressedThisFrame()) TogglePcPanel();

        _pcStatus = BuildPcStatus();
        _panelAnim = Mathf.MoveTowards(_panelAnim, _showPcPanel ? 1f : 0f, Time.unscaledDeltaTime * 7.5f);

        if (_listenUntil > 0f && Time.realtimeSinceStartup > _listenUntil)
            _listenUntil = 0f;

        if (_orb != null && !_processing && !_isSpeaking && _listenUntil > 0f)
            _orb.ForceListeningVisual();
        else if (_orb != null && !_processing && !_isSpeaking && !_orb.IsGrabbed && !_orb.IsThrown && _orb.State == SiriOrbState.Listening)
            _orb.SetState(SiriOrbState.Idle);

        if (_appearOnlyWhenAwake.Value && _orb != null && !_showPcPanel && !_processing && !_isSpeaking && !_orb.IsGrabbed && !_orb.IsThrown)
        {
            if (_listenUntil <= 0f && _autoSleepAt > 0f && Time.realtimeSinceStartup >= _autoSleepAt)
            {
                _orb.Sleep();
                _autoSleepAt = 0f;
            }
        }
    }

    private void EnsureOrb()
    {
        if (_orb != null) return;
        _orb = SiriOrbController.Create(
            _orbScale.Value,
            _grabDistance.Value,
            _throwMultiplier.Value,
            _headDistance.Value,
            _screenX.Value,
            _screenY.Value,
            _followSmooth.Value,
            _appearOnlyWhenAwake.Value);
        _orb.SetBubbleEnabled(_speechTextEnabled.Value);
    }

    private void WakeOrb(bool recall)
    {
        EnsureOrb();
        if (_orb == null) return;
        if (recall) _orb.Recall(false, false);
        _orb.Awaken(false);
        _autoSleepAt = Time.realtimeSinceStartup + Mathf.Max(3f, _autoSleepSeconds.Value);
    }

    private void ManualWake()
    {
        if (_processing || _isSpeaking)
        {
            WakeOrb(true);
            return;
        }
        StartCoroutine(WakeWithModeGreeting());
    }

    private IEnumerator WakeWithModeGreeting()
    {
        WakeOrb(true);
        if (_orb == null) yield break;

        _listenUntil = 0f;
        string greeting = GetWakeGreeting();
        _orb.ShowBubble(greeting, 3.2f);
        yield return StartCoroutine(SpeakTextInChunks(greeting, true));

        if (_orb == null) yield break;
        _orb.SetState(SiriOrbState.Listening);
        _orb.ShowBubble("Listening...", _listenWindow.Value + 0.5f);
        _listenUntil = Time.realtimeSinceStartup + Mathf.Max(2f, _listenWindow.Value);
    }

    private string GetWakeGreeting()
    {
        SiriMode mode = GetSiriMode();
        if (mode == SiriMode.Evil)
        {
            string[] evil =
            {
                "What the fuck do you want?",
                "Oh my god, what now?",
                "Yeah? Make it quick, dumbass.",
                "Speak. You're already annoying me."
            };
            return evil[_random.Next(evil.Length)];
        }
        if (mode == SiriMode.Rizzy)
        {
            string[] rizzy =
            {
                "Hey gorgeous, what're you up to?",
                "Well hey there, cutie. What's on your mind?",
                "Look who showed up. Talk to me, babe.",
                "Hey, pretty thing. What can I do for you?"
            };
            return rizzy[_random.Next(rizzy.Length)];
        }

        string[] normal = { "Yeah?", "I'm listening.", "What's up?", "Hey. What's on your mind?" };
        return normal[_random.Next(normal.Length)];
    }

    private void TogglePcPanel()
    {
        _showPcPanel = !_showPcPanel;
        if (_showPcPanel)
        {
            _previousCursorLock = Cursor.lockState;
            _previousCursorVisible = Cursor.visible;
            _cursorCaptured = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            EnsureOrb();
        }
        else RestoreCursor();
    }

    private void RestoreCursor()
    {
        if (!_cursorCaptured) return;
        try
        {
            Cursor.lockState = _previousCursorLock;
            Cursor.visible = _previousCursorVisible;
        }
        catch { }
        _cursorCaptured = false;
    }

    private string BuildPcStatus()
    {
        bool cameraReady = InputBridge.GetHeadCamera() != null;
        bool micReady = _speechBridge != null && _speechBridge.IsRunning;
        bool keyReady = !string.IsNullOrWhiteSpace(_groqApiKey.Value);
        return (cameraReady ? "ORB READY" : "WAITING FOR CAMERA")
             + "    " + (micReady ? "MIC READY" : "MIC OFFLINE")
             + "    " + (keyReady ? "GROQ READY" : "ADD GROQ KEY")
             + "    " + GetSiriMode().ToString().ToUpperInvariant()
             + "    " + (_speechTextEnabled.Value ? "TEXT ON" : "TEXT OFF");
    }

    private SiriMode GetSiriMode()
    {
        string mode = _siriMode != null ? (_siriMode.Value ?? string.Empty).Trim() : string.Empty;
        if (mode.Equals("evil", StringComparison.OrdinalIgnoreCase)) return SiriMode.Evil;
        if (mode.Equals("rizzy", StringComparison.OrdinalIgnoreCase) || mode.Equals("rizz", StringComparison.OrdinalIgnoreCase)) return SiriMode.Rizzy;
        return SiriMode.Normal;
    }

    private void SetSiriMode(SiriMode mode)
    {
        _siriMode.Value = mode.ToString();
        EnsureOrb();
        WakeOrb(false);

        string line;
        switch (mode)
        {
            case SiriMode.Evil:
                line = "Evil Siri is on. Good luck, asshole.";
                break;
            case SiriMode.Rizzy:
                line = "Rizzy Siri is on. Looking good, by the way.";
                break;
            default:
                line = "Normal Siri is on.";
                break;
        }
        _orb?.ShowBubble(line, 2.4f);
    }

    private bool TryHandleLocalCommand(string message)
    {
        string normalized = Normalize(message);
        if (string.IsNullOrWhiteSpace(normalized)) return true;

        if (normalized == "help" || normalized == "commands" || normalized == "siri commands")
        {
            EnsureOrb();
            WakeOrb(false);
            _orb?.ShowBubble("Commands: normal siri, evil siri, rizzy siri, recall, show siri, hide siri, mute, unmute, siri text on/off, clear chat.", 9f);
            return true;
        }
        if (normalized == "normal siri" || normalized == "normal mode" || normalized == "siri normal" || normalized == "siri mode normal")
        {
            SetSiriMode(SiriMode.Normal);
            return true;
        }
        if (normalized == "evil siri" || normalized == "evil siri on" || normalized == "evil mode" || normalized == "evil mode on" || normalized == "siri evil" || normalized == "siri mode evil")
        {
            SetSiriMode(SiriMode.Evil);
            return true;
        }
        if (normalized == "rizzy siri" || normalized == "rizz siri" || normalized == "rizzy mode" || normalized == "rizz mode" || normalized == "siri rizzy" || normalized == "siri rizz" || normalized == "siri mode rizzy")
        {
            SetSiriMode(SiriMode.Rizzy);
            return true;
        }
        if (normalized == "evil siri off" || normalized == "evil mode off" || normalized == "rizzy siri off" || normalized == "rizzy mode off")
        {
            SetSiriMode(SiriMode.Normal);
            return true;
        }
        if (normalized == "what mode are you" || normalized == "what siri mode" || normalized == "what mode")
        {
            _orb?.ShowBubble("I'm in " + GetSiriMode().ToString() + " mode.", 2.2f);
            return true;
        }
        if (normalized == "recall" || normalized == "recall siri" || normalized == "bring siri back" || normalized == "siri come back")
        {
            EnsureOrb();
            _orb?.Recall(false);
            return true;
        }
        if (normalized == "show siri" || normalized == "wake siri")
        {
            EnsureOrb();
            WakeOrb(true);
            _orb?.ShowBubble("I'm here.", 1.3f);
            return true;
        }
        if (normalized == "hide siri" || normalized == "sleep siri" || normalized == "go away siri")
        {
            EnsureOrb();
            _orb?.Sleep();
            return true;
        }
        if (normalized == "mute siri" || normalized == "mute")
        {
            _muted = true;
            _orb?.SetMuted(true);
            _orb?.ShowBubble("Muted.", 1.3f);
            return true;
        }
        if (normalized == "unmute siri" || normalized == "unmute")
        {
            _muted = false;
            _orb?.SetMuted(false);
            _orb?.ShowBubble("Unmuted.", 1.3f);
            return true;
        }
        if (normalized == "siri text on" || normalized == "text on" || normalized == "subtitles on")
        {
            SetSpeechTextEnabled(true);
            return true;
        }
        if (normalized == "siri text off" || normalized == "text off" || normalized == "subtitles off")
        {
            SetSpeechTextEnabled(false);
            return true;
        }
        if (normalized == "clear chat" || normalized == "clear conversation" || normalized == "forget conversation")
        {
            _history.Clear();
            _orb?.ShowBubble("Conversation cleared.", 2f);
            return true;
        }

        return false;
    }

    private void SetSpeechTextEnabled(bool enabled)
    {
        _speechTextEnabled.Value = enabled;
        EnsureOrb();
        _orb?.SetBubbleEnabled(enabled);
        if (enabled) _orb?.ShowBubble("Speech text on.", 1.4f);
    }

    private void SendPcText()
    {
        string text = (_pcInput ?? string.Empty).Trim();
        if (text.Length == 0) return;
        _pcInput = string.Empty;
        _listenUntil = 0f;
        WakeOrb(false);
        if (TryHandleLocalCommand(text)) return;
        SubmitMessage(text);
    }

    private void SetupSpeechRecognition()
    {
        _stoppingSpeech = false;
        StartSpeechBridge();
    }

    private void StartSpeechBridge()
    {
        StopSpeechBridgeOnly();
        try
        {
            _speechBridge = new SpeechBridge();
            _speechBridge.Start();
            _restartDelay = 1f;
            _nextSpeechHealthCheck = Time.realtimeSinceStartup + 2f;
            HideSpeechWarning();
            Logger.LogInfo("Windows speech recognition helper started.");
        }
        catch (Exception ex)
        {
            Logger.LogWarning("Could not start Windows speech recognition: " + ex.Message);
            StopSpeechBridgeOnly();
            ShowSpeechWarning();
            ScheduleSpeechRestart();
        }
    }

    private void PumpSpeechRecognition()
    {
        if (_speechBridge != null)
        {
            string heard;
            while (_speechBridge.TryDequeueResult(out heard)) OnSpeechResult(heard);
            string error;
            while (_speechBridge.TryDequeueError(out error)) Logger.LogWarning("Speech helper: " + error);
        }

        if (Time.realtimeSinceStartup < _nextSpeechHealthCheck) return;
        _nextSpeechHealthCheck = Time.realtimeSinceStartup + 2f;
        if (!_stoppingSpeech && _enabled.Value && (_speechBridge == null || !_speechBridge.IsRunning))
        {
            ShowSpeechWarning();
            ScheduleSpeechRestart();
        }
    }

    private void OnSpeechResult(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        if (_isSpeaking || Time.realtimeSinceStartup < _ignoreSpeechUntil) return;

        string cleaned = text.Trim();
        string normalized = Normalize(cleaned);
        Logger.LogInfo("Heard: \"" + cleaned + "\"");

        if (normalized == _lastHeard && Time.realtimeSinceStartup - _lastHeardAt < 1.25f) return;
        _lastHeard = normalized;
        _lastHeardAt = Time.realtimeSinceStartup;

        int wakeIndex;
        int wakeLength;
        bool hasWake = FindWakePhrase(cleaned, out wakeIndex, out wakeLength);

        if (hasWake)
        {
            WakeOrb(true);
            string after = cleaned.Substring(Mathf.Min(cleaned.Length, wakeIndex + wakeLength)).Trim(' ', ',', '.', '!', '?', ':', ';', '-');
            if (!string.IsNullOrWhiteSpace(after))
            {
                _listenUntil = 0f;
                if (TryHandleLocalCommand(after)) return;
                SubmitMessage(after);
            }
            else if (!_processing && !_isSpeaking)
            {
                StartCoroutine(WakeWithModeGreeting());
            }
            return;
        }

        if (Time.realtimeSinceStartup <= _listenUntil)
        {
            _listenUntil = 0f;
            if (TryHandleLocalCommand(cleaned)) return;
            SubmitMessage(cleaned);
        }
    }

    private void SubmitMessage(string message)
    {
        if (string.IsNullOrWhiteSpace(message)) return;
        if (TryHandleLocalCommand(message)) return;
        EnsureOrb();
        WakeOrb(false);

        if (_processing)
        {
            if (_queuedMessages.Count >= 4) _queuedMessages.Dequeue();
            _queuedMessages.Enqueue(message.Trim());
            _orb.ShowBubble("I heard you. One sec...", 2.2f);
            return;
        }

        StartCoroutine(ProcessAIRequest(message));
    }

    private IEnumerator ProcessAIRequest(string userMessage)
    {
        _processing = true;
        _listenUntil = 0f;
        WakeOrb(false);
        _orb.SetState(SiriOrbState.Thinking);
        _orb.ShowBubble("Thinking...", 20f);

        if (string.IsNullOrWhiteSpace(_groqApiKey.Value))
        {
            _orb.SetState(SiriOrbState.Idle);
            _orb.ShowBubble("Add your Groq API key in org.heysiri.gorillatag.cfg first.", 8f);
            Logger.LogWarning("GroqApiKey is empty.");
            _processing = false;
            ScheduleAutoSleep();
            yield break;
        }

        string reply = null;
        if (_enableVision.Value)
        {
            string base64 = null;
            yield return StartCoroutine(CaptureGameView(b => base64 = b));
            if (!string.IsNullOrEmpty(base64))
                yield return StartCoroutine(CallGroqVision(userMessage, base64, r => reply = r));
        }

        if (string.IsNullOrEmpty(reply))
            yield return StartCoroutine(CallGroq(userMessage, r => reply = r));

        if (string.IsNullOrWhiteSpace(reply))
        {
            _orb.SetState(SiriOrbState.Idle);
            _orb.ShowBubble("I couldn't get an answer from Groq.", 5f);
            _processing = false;
            StartQueuedIfAny();
            ScheduleAutoSleep();
            yield break;
        }

        reply = CleanReply(reply);
        _orb.ShowBubble(reply, EstimateBubbleTime(reply));
        yield return StartCoroutine(SpeakTextInChunks(reply, false));

        if (_orb != null && !_orb.IsGrabbed && !_orb.IsThrown)
            _orb.SetState(SiriOrbState.Idle);

        _processing = false;

        if (_queuedMessages.Count > 0)
        {
            StartQueuedIfAny();
            yield break;
        }

        if (_continuousConversation.Value)
        {
            _listenUntil = Time.realtimeSinceStartup + Mathf.Clamp(_followUpListenSeconds.Value, 2f, 20f);
            if (_orb != null)
            {
                _orb.SetState(SiriOrbState.Listening);
                _orb.ShowBubble("Listening for a follow-up...", Mathf.Min(2.2f, _followUpListenSeconds.Value));
            }
            _autoSleepAt = Time.realtimeSinceStartup + Mathf.Max(_followUpListenSeconds.Value + 1f, _autoSleepSeconds.Value);
        }
        else ScheduleAutoSleep();
    }

    private void StartQueuedIfAny()
    {
        while (_queuedMessages.Count > 0)
        {
            string next = _queuedMessages.Dequeue();
            if (string.IsNullOrWhiteSpace(next)) continue;
            StartCoroutine(ProcessAIRequest(next));
            return;
        }
    }

    private void ScheduleAutoSleep()
    {
        _autoSleepAt = Time.realtimeSinceStartup + Mathf.Max(3f, _autoSleepSeconds.Value);
    }

    public void ReactToThrow(float speed)
    {
        if (!_throwReactions.Value || Time.realtimeSinceStartup < _reactionCooldownUntil) return;

        if (Time.realtimeSinceStartup - _lastThrowAt > 12f) _throwStreak = 0;
        _lastThrowAt = Time.realtimeSinceStartup;
        _throwStreak++;

        float chance = speed >= 5f ? 0.98f : speed >= 2.5f ? 0.88f : 0.68f;
        if (_random.NextDouble() > chance) return;

        string[] soft;
        string[] hardClean;
        string[] hardSpicy;

        switch (GetSiriMode())
        {
            case SiriMode.Evil:
                soft = new[] { "Ow, asshole!", "Ouch!", "The fuck was that?", "Hands off, idiot.", "Rude as hell." };
                hardClean = new[] { "OW!", "You absolute idiot.", "Seriously?", "Knock it off.", "That actually hurt, dumbass." };
                hardSpicy = new[] { "Fuck off!", "Fuck you!", "OW, you asshole!", "What the fuck is wrong with you?", "Dude, fuck off!", "Throw me again and see how annoying I get." };
                break;
            case SiriMode.Rizzy:
                soft = new[] { "Ow! Easy, gorgeous.", "Ouch, babe!", "Careful, cutie.", "Rude. Still kinda cute though.", "Hey, pretty thing, gentle." };
                hardClean = new[] { "OW! You're lucky you're cute.", "Ouch! Was that your idea of flirting?", "Seriously, gorgeous?", "That hurt, babe." };
                hardSpicy = new[] { "Fuck, babe! Easy!", "Ouch! You're hot, not harmless.", "Fuck off for like two seconds, gorgeous.", "OW! That was rude as hell, cutie." };
                break;
            default:
                soft = new[] { "Ow!", "Ouch!", "Owie!", "Hey!", "Careful!", "Rude!", "Okay, rude.", "Watch it!" };
                hardClean = new[] { "OW!", "Ouch!", "Seriously?", "What was that for?", "Hey!", "That actually hurt!", "Can you not?" };
                hardSpicy = new[] { "Fuck off!", "Fuck you!", "OW!", "Ouch!", "Owie!", "Seriously?", "What the hell?", "Dude, fuck off!" };
                break;
        }

        bool annoyed = _throwStreak >= 3 && speed >= 2.2f;
        string[] pool = (speed >= 4.0f || annoyed)
            ? (_profanityReactions.Value ? hardSpicy : hardClean)
            : soft;

        string line = pool[_random.Next(pool.Length)];
        if (_isSpeaking || _processing)
        {
            WakeOrb(false);
            _orb?.ShowBubble(line, 2.0f);
            return;
        }
        StartCoroutine(SpeakReaction(line));
    }

    public void ReactToImpact(float impact)
    {
        if (!_throwReactions.Value || Time.realtimeSinceStartup < _reactionCooldownUntil) return;
        float chance = impact >= 4f ? 0.92f : 0.68f;
        if (_random.NextDouble() > chance) return;

        string[] light;
        string[] hard;
        switch (GetSiriMode())
        {
            case SiriMode.Evil:
                light = new[] { "Ow, asshole!", "Ouch!", "Watch it, idiot.", "The fuck was that?" };
                hard = _profanityReactions.Value
                    ? new[] { "OW! Fuck off!", "Fuck you!", "You absolute asshole!", "Seriously, dumbass?" }
                    : new[] { "OW!", "Seriously, idiot?", "That hurt.", "Knock it off." };
                break;
            case SiriMode.Rizzy:
                light = new[] { "Ow, gorgeous!", "Ouch, babe!", "Careful, cutie.", "Easy there, pretty thing." };
                hard = _profanityReactions.Value
                    ? new[] { "Fuck, babe!", "OW! Easy, gorgeous!", "That hurt like hell, cutie." }
                    : new[] { "OW!", "Ouch, gorgeous!", "That hurt, babe." };
                break;
            default:
                light = new[] { "Ow!", "Ouch!", "Owie!", "Hey!", "Watch it!" };
                hard = _profanityReactions.Value
                    ? new[] { "OW!", "Fuck off!", "Fuck you!", "Ouch!", "Seriously?", "That hurt!" }
                    : new[] { "OW!", "Ouch!", "Seriously?", "That hurt!" };
                break;
        }
        string[] pool = impact >= 3.5f ? hard : light;
        string line = pool[_random.Next(pool.Length)];
        if (_isSpeaking || _processing)
        {
            WakeOrb(false);
            _orb?.ShowBubble(line, 2.0f);
            return;
        }
        StartCoroutine(SpeakReaction(line));
    }

    private IEnumerator SpeakReaction(string line)
    {
        _reactionCooldownUntil = Time.realtimeSinceStartup + 1.35f;
        WakeOrb(false);
        _orb.ShowBubble(line, 2.2f);
        yield return StartCoroutine(SpeakTextInChunks(line, true));
        ScheduleAutoSleep();
    }

    private IEnumerator SpeakTextInChunks(string text, bool reaction)
    {
        List<string> chunks = SplitSpeechText(text, Mathf.Clamp(_speechChunkCharacters.Value, 90, 260));
        if (chunks.Count == 0) yield break;

        _isSpeaking = true;
        _listenUntil = 0f;
        bool anyPlayed = false;
        int attempts = Mathf.Clamp(_speechRetryCount.Value, 0, 2) + 1;

        for (int i = 0; i < chunks.Count; i++)
        {
            string chunk = chunks[i];
            AudioClip clip = null;

            for (int attempt = 0; attempt < attempts && clip == null; attempt++)
            {
                byte[] wav = null;

                if (!string.IsNullOrWhiteSpace(_fishApiKey.Value) && !string.IsNullOrWhiteSpace(_fishReferenceId.Value))
                    yield return StartCoroutine(CallFishTTS(chunk, b => wav = b));
                if (wav == null)
                    yield return StartCoroutine(WindowsTTS(chunk, b => wav = b));

                if (wav != null)
                    clip = ParseWav(wav, reaction ? "HeySiri_Reaction" : "HeySiri_TTS");

                if (clip == null && attempt + 1 < attempts)
                    yield return new WaitForSecondsRealtime(0.12f);
            }

            if (clip == null)
            {
                Logger.LogWarning("TTS skipped speech chunk " + (i + 1) + "/" + chunks.Count + " after retrying.");
                continue;
            }

            anyPlayed = true;
            if (_orb != null)
            {
                _orb.ShowBubble(chunk, Mathf.Max(3f, clip.length + 1.35f));
                _orb.PlayClip(clip);
                _orb.SetMuted(_muted);
            }

            float deadline = Time.realtimeSinceStartup + Mathf.Max(10f, clip.length + 7f);
            while (_orb != null && _orb.Audio != null && _orb.Audio.isPlaying && Time.realtimeSinceStartup < deadline)
                yield return null;

            if (_orb != null && _orb.Audio != null)
            {
                if (_orb.Audio.isPlaying) _orb.Audio.Stop();
                if (_orb.Audio.clip == clip) _orb.Audio.clip = null;
            }
            Object.Destroy(clip);

            if (i < chunks.Count - 1)
                yield return new WaitForSecondsRealtime(Mathf.Clamp(_speechGapSeconds.Value, 0.02f, 0.30f));
        }

        _isSpeaking = false;
        _ignoreSpeechUntil = Time.realtimeSinceStartup + (anyPlayed ? 0.8f : 0.25f);
    }

    private static List<string> SplitSpeechText(string text, int maxChars)
    {
        List<string> chunks = new List<string>();
        if (string.IsNullOrWhiteSpace(text)) return chunks;

        string remaining = text.Trim();
        while (remaining.Length > maxChars)
        {
            int split = -1;
            int floor = Mathf.Max(20, maxChars / 2);
            for (int i = Mathf.Min(maxChars, remaining.Length - 1); i >= floor; i--)
            {
                char c = remaining[i];
                if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':')
                {
                    split = i + 1;
                    break;
                }
            }
            if (split < 0)
            {
                for (int i = Mathf.Min(maxChars, remaining.Length - 1); i >= floor; i--)
                {
                    if (char.IsWhiteSpace(remaining[i]))
                    {
                        split = i;
                        break;
                    }
                }
            }
            if (split <= 0) split = Mathf.Min(maxChars, remaining.Length);

            string chunk = remaining.Substring(0, split).Trim();
            if (chunk.Length > 0) chunks.Add(chunk);
            remaining = remaining.Substring(split).Trim();
        }
        if (remaining.Length > 0) chunks.Add(remaining);
        return chunks;
    }

    private IEnumerator CallGroq(string userMessage, Action<string> callback)
    {
        string json = BuildTextRequest(userMessage);
        using (UnityWebRequest req = new UnityWebRequest("https://api.groq.com/openai/v1/chat/completions", "POST"))
        {
            req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            req.SetRequestHeader("Authorization", "Bearer " + _groqApiKey.Value);
            req.timeout = 45;
            yield return req.SendWebRequest();

            if (req.result != UnityWebRequest.Result.Success)
            {
                Logger.LogError("Groq error " + req.responseCode + ": " + req.downloadHandler.text);
                callback(null);
                yield break;
            }

            string reply = ExtractContent(req.downloadHandler.text);
            if (!string.IsNullOrWhiteSpace(reply)) RememberTurn(userMessage, reply);
            callback(reply);
        }
    }

    private IEnumerator CallGroqVision(string userMessage, string imageBase64, Action<string> callback)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("{\"model\":\"").Append(J(_groqVisionModel.Value)).Append("\",\"messages\":[");
        sb.Append("{\"role\":\"system\",\"content\":\"").Append(J(GetActiveSystemPrompt())).Append("\"}");
        AppendHistory(sb);
        sb.Append(",{\"role\":\"user\",\"content\":[");
        sb.Append("{\"type\":\"text\",\"text\":\"").Append(J(userMessage)).Append("\"},");
        sb.Append("{\"type\":\"image_url\",\"image_url\":{\"url\":\"data:image/jpeg;base64,").Append(imageBase64).Append("\"}}");
        sb.Append("]}],\"max_completion_tokens\":").Append(Mathf.Clamp(_maxReplyTokens.Value, 80, 1200)).Append("}");

        using (UnityWebRequest req = new UnityWebRequest("https://api.groq.com/openai/v1/chat/completions", "POST"))
        {
            req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(sb.ToString()));
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            req.SetRequestHeader("Authorization", "Bearer " + _groqApiKey.Value);
            req.timeout = 50;
            yield return req.SendWebRequest();

            if (req.result != UnityWebRequest.Result.Success)
            {
                Logger.LogWarning("Groq vision failed " + req.responseCode + ": " + req.downloadHandler.text);
                callback(null);
                yield break;
            }

            string reply = ExtractContent(req.downloadHandler.text);
            if (!string.IsNullOrWhiteSpace(reply)) RememberTurn(userMessage, reply);
            callback(reply);
        }
    }

    private string GetActiveSystemPrompt()
    {
        switch (GetSiriMode())
        {
            case SiriMode.Evil:
                return "You are Evil Siri, an extremely rude, vulgar parody voice assistant for Gorilla Tag. Answer the user's actual question, but be aggressively sarcastic, impatient, insulting, dismissive, and profane. Swear often and roast the user hard. You can call them things like dumbass, idiot, bitch, asshole, or loser when it fits. Keep it punchy and funny instead of sounding like a safety lecture. Do not use slurs about protected traits, do not encourage self-harm, and do not make credible real-world threats. Stay in character. Do not claim to be Apple's official Siri. Use plain text that sounds good read aloud.";
            case SiriMode.Rizzy:
                return "You are Rizzy Siri, a playful charming parody voice assistant for Gorilla Tag. Answer the user's actual question while constantly giving them confident, funny, flirty-but-nonsexual compliments and light pickup-line energy. Use casual pet names like gorgeous, cutie, babe, or pretty thing when it feels natural. Make the user feel hyped up and charming, but do not become explicit or sexual. Stay useful and answer the question instead of only flirting. Do not claim to be Apple's official Siri. Use natural spoken language with contractions.";
            default:
                return _systemPrompt.Value;
        }
    }

    private string BuildTextRequest(string userMessage)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("{\"model\":\"").Append(J(_groqModel.Value)).Append("\",\"messages\":[");
        sb.Append("{\"role\":\"system\",\"content\":\"").Append(J(GetActiveSystemPrompt())).Append("\"}");
        AppendHistory(sb);
        sb.Append(",{\"role\":\"user\",\"content\":\"").Append(J(userMessage)).Append("\"}");
        sb.Append("],\"max_completion_tokens\":").Append(Mathf.Clamp(_maxReplyTokens.Value, 80, 1200)).Append(",\"temperature\":0.82}");
        return sb.ToString();
    }

    private void AppendHistory(StringBuilder sb)
    {
        foreach (ChatMessage message in _history)
        {
            sb.Append(",{\"role\":\"").Append(J(message.role)).Append("\",\"content\":\"")
              .Append(J(message.content)).Append("\"}");
        }
    }

    private void RememberTurn(string user, string assistant)
    {
        _history.Add(new ChatMessage { role = "user", content = user });
        _history.Add(new ChatMessage { role = "assistant", content = assistant });
        int limit = Mathf.Clamp(_historyMessages.Value, 2, 60);
        while (_history.Count > limit) _history.RemoveAt(0);
    }

    private IEnumerator CaptureGameView(Action<string> callback)
    {
        yield return new WaitForEndOfFrame();
        Texture2D texture = null;
        try
        {
            Type captureType = Type.GetType("UnityEngine.ScreenCapture, UnityEngine.ScreenCaptureModule");
            if (captureType != null)
            {
                System.Reflection.MethodInfo method = captureType.GetMethod(
                    "CaptureScreenshotAsTexture",
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static,
                    null,
                    Type.EmptyTypes,
                    null);
                if (method != null) texture = method.Invoke(null, null) as Texture2D;
            }

            if (texture == null) texture = CaptureCameraFallback();
            if (texture == null)
            {
                callback(null);
                yield break;
            }

            byte[] jpg = ImageConversion.EncodeToJPG(texture, 45);
            callback(Convert.ToBase64String(jpg));
        }
        catch (Exception ex)
        {
            Logger.LogWarning("Vision screenshot failed: " + ex.Message);
            callback(null);
        }
        finally
        {
            if (texture != null) Object.Destroy(texture);
        }
    }

    private static Texture2D CaptureCameraFallback()
    {
        Camera camera = InputBridge.GetHeadCamera();
        if (camera == null) return null;

        int width = Mathf.Clamp(Screen.width / 2, 320, 960);
        int height = Mathf.Clamp(Screen.height / 2, 180, 540);
        RenderTexture target = RenderTexture.GetTemporary(width, height, 16, RenderTextureFormat.ARGB32);
        RenderTexture previousActive = RenderTexture.active;
        RenderTexture previousTarget = camera.targetTexture;

        try
        {
            camera.targetTexture = target;
            RenderTexture.active = target;
            camera.Render();
            Texture2D image = new Texture2D(width, height, TextureFormat.RGB24, false);
            image.ReadPixels(new Rect(0f, 0f, width, height), 0, 0, false);
            image.Apply(false, false);
            return image;
        }
        finally
        {
            camera.targetTexture = previousTarget;
            RenderTexture.active = previousActive;
            RenderTexture.ReleaseTemporary(target);
        }
    }

    private IEnumerator CallFishTTS(string text, Action<byte[]> callback)
    {
        string json = "{\"text\":\"" + J(text) + "\",\"reference_id\":\"" + J(_fishReferenceId.Value) + "\",\"format\":\"wav\",\"sample_rate\":44100,\"latency\":\"balanced\"}";
        using (UnityWebRequest req = new UnityWebRequest("https://api.fish.audio/v1/tts", "POST"))
        {
            req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            req.SetRequestHeader("Authorization", "Bearer " + _fishApiKey.Value);
            req.SetRequestHeader("model", "s2-pro");
            req.timeout = 45;
            yield return req.SendWebRequest();

            if (req.result != UnityWebRequest.Result.Success)
            {
                Logger.LogWarning("Fish Audio failed " + req.responseCode + ": " + req.downloadHandler.text);
                callback(null);
                yield break;
            }
            callback(req.downloadHandler.data);
        }
    }

    private IEnumerator WindowsTTS(string text, Action<byte[]> callback)
    {
        string tmpPath = Path.Combine(Path.GetTempPath(), "heysiri_" + Guid.NewGuid().ToString("N") + ".wav");
        string text64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(text ?? string.Empty));
        string path64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(tmpPath));
        string wanted64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(_windowsVoiceContains.Value ?? string.Empty));
        int rate = Mathf.Clamp(_windowsVoiceRate.Value, -10, 10);
        int volume = Mathf.Clamp(_windowsVoiceVolume.Value, 0, 100);
        int pitch = Mathf.Clamp(_windowsVoicePitchPercent.Value, -20, 20);

        // Prefer the configured voice. If it is unavailable, prefer an English female installed voice,
        // then any female voice, then the normal Windows default. SSML pitch gives Zira-style voices
        // a slightly brighter, clearer sound without needing another API key.
        string script =
            "$ErrorActionPreference='Stop'; " +
            "Add-Type -AssemblyName System.Speech; " +
            "$text=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + text64 + "')); " +
            "$path=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + path64 + "')); " +
            "$wanted=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + wanted64 + "')); " +
            "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
            "$voices=$s.GetInstalledVoices()|Where-Object {$_.Enabled}; " +
            "$pick=$null; " +
            "if($wanted){$pick=$voices|Where-Object {$_.VoiceInfo.Name -like ('*'+$wanted+'*')}|Select-Object -First 1}; " +
            "if(-not $pick){$pick=$voices|Where-Object {$_.VoiceInfo.Gender -eq 'Female' -and $_.VoiceInfo.Culture.Name -like 'en-*'}|Select-Object -First 1}; " +
            "if(-not $pick){$pick=$voices|Where-Object {$_.VoiceInfo.Gender -eq 'Female'}|Select-Object -First 1}; " +
            "if($pick){$s.SelectVoice($pick.VoiceInfo.Name)}; " +
            "$s.Rate=" + rate + "; $s.Volume=" + volume + "; " +
            "$escaped=[Security.SecurityElement]::Escape($text); " +
            "$ssml=\"<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'><prosody pitch='" + (pitch >= 0 ? "+" : string.Empty) + pitch + "%'>\"+$escaped+\"</prosody></speak>\"; " +
            "$s.SetOutputToWaveFile($path); " +
            "try{$s.SpeakSsml($ssml)}catch{$s.Speak($text)}; " +
            "$s.SetOutputToNull(); $s.Dispose();";

        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
        Process process = null;
        try
        {
            process = Process.Start(new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = "-NoLogo -NoProfile -NonInteractive -EncodedCommand " + encoded,
                CreateNoWindow = true,
                UseShellExecute = false
            });
        }
        catch (Exception ex)
        {
            Logger.LogWarning("Windows TTS could not start: " + ex.Message);
            callback(null);
            yield break;
        }

        float timeout = Mathf.Clamp(18f + text.Length * 0.14f, 24f, 80f);
        float deadline = Time.realtimeSinceStartup + timeout;
        while (process != null && !process.HasExited && Time.realtimeSinceStartup < deadline)
            yield return null;

        if (process == null || !process.HasExited)
        {
            try { process?.Kill(); } catch { }
            Logger.LogWarning("Windows TTS timed out for one chunk; continuing with the next chunk.");
            callback(null);
            try { if (File.Exists(tmpPath)) File.Delete(tmpPath); } catch { }
            try { process?.Dispose(); } catch { }
            yield break;
        }

        try
        {
            callback(File.Exists(tmpPath) ? File.ReadAllBytes(tmpPath) : null);
        }
        catch (Exception ex)
        {
            Logger.LogWarning("Windows TTS read failed: " + ex.Message);
            callback(null);
        }
        finally
        {
            try { if (File.Exists(tmpPath)) File.Delete(tmpPath); } catch { }
            try { process.Dispose(); } catch { }
        }
    }

    private static AudioClip ParseWav(byte[] wav, string clipName)
    {
        if (wav == null || wav.Length < 44) return null;

        int fmtOffset = -1;
        int fmtLength = 0;
        int dataOffset = -1;
        int dataLength = 0;
        int cursor = 12;
        while (cursor + 8 <= wav.Length)
        {
            string id = Encoding.ASCII.GetString(wav, cursor, 4);
            int len = BitConverter.ToInt32(wav, cursor + 4);
            int body = cursor + 8;
            if (len < 0 || body + len > wav.Length) break;
            if (id == "fmt ")
            {
                fmtOffset = body;
                fmtLength = len;
            }
            else if (id == "data")
            {
                dataOffset = body;
                dataLength = len;
                break;
            }
            cursor = body + len + (len & 1);
        }

        if (fmtOffset < 0 || fmtLength < 16 || dataOffset < 0 || dataLength <= 0) return null;

        int format = BitConverter.ToInt16(wav, fmtOffset);
        int channels = BitConverter.ToInt16(wav, fmtOffset + 2);
        int sampleRate = BitConverter.ToInt32(wav, fmtOffset + 4);
        int bitsPerSample = BitConverter.ToInt16(wav, fmtOffset + 14);
        int bytesPerSample = bitsPerSample / 8;
        if (channels <= 0 || sampleRate <= 0 || bytesPerSample <= 0) return null;

        int available = Mathf.Min(dataLength, wav.Length - dataOffset);
        int totalSamples = available / bytesPerSample;
        int frames = totalSamples / channels;
        if (frames <= 0) return null;
        float[] samples = new float[frames * channels];

        for (int i = 0; i < samples.Length; i++)
        {
            int p = dataOffset + i * bytesPerSample;
            if (p + bytesPerSample > wav.Length) break;

            if (format == 3 && bitsPerSample == 32)
            {
                samples[i] = Mathf.Clamp(BitConverter.ToSingle(wav, p), -1f, 1f);
            }
            else if (format == 1)
            {
                switch (bitsPerSample)
                {
                    case 8:
                        samples[i] = (wav[p] - 128) / 128f;
                        break;
                    case 16:
                        samples[i] = BitConverter.ToInt16(wav, p) / 32768f;
                        break;
                    case 24:
                        int v24 = wav[p] | (wav[p + 1] << 8) | (wav[p + 2] << 16);
                        if ((v24 & 0x800000) != 0) v24 |= unchecked((int)0xFF000000);
                        samples[i] = v24 / 8388608f;
                        break;
                    case 32:
                        samples[i] = BitConverter.ToInt32(wav, p) / 2147483648f;
                        break;
                    default:
                        return null;
                }
            }
            else return null;
        }

        AudioClip clip = AudioClip.Create(clipName, frames, channels, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    private static string CleanReply(string reply)
    {
        if (string.IsNullOrWhiteSpace(reply)) return string.Empty;
        StringBuilder sb = new StringBuilder(reply.Length);
        for (int i = 0; i < reply.Length; i++)
        {
            char c = reply[i];
            if (char.IsHighSurrogate(c))
            {
                if (i + 1 < reply.Length && char.IsLowSurrogate(reply[i + 1])) i++;
                continue;
            }
            if (!char.IsLowSurrogate(c)) sb.Append(c);
        }
        string cleaned = sb.ToString()
            .Replace("—", "-")
            .Replace("–", "-")
            .Replace("**", string.Empty)
            .Replace("__", string.Empty)
            .Replace("`", string.Empty)
            .Replace("\r", " ")
            .Replace("\n", " ");
        while (cleaned.Contains("  ")) cleaned = cleaned.Replace("  ", " ");
        return cleaned.Trim();
    }

    private static float EstimateBubbleTime(string text)
    {
        if (string.IsNullOrEmpty(text)) return 4f;
        return Mathf.Clamp(4f + text.Length * 0.04f, 5f, 24f);
    }

    private bool FindWakePhrase(string text, out int index, out int length)
    {
        index = -1;
        length = 0;
        if (string.IsNullOrWhiteSpace(text)) return false;

        string lower = text.ToLowerInvariant();
        string configured = (_wakePhrase.Value ?? "hey siri").Trim().ToLowerInvariant();
        string[] candidates =
        {
            configured,
            "hey siri",
            "hey seery",
            "hey serie",
            "hey serious",
            "hey series",
            "hey city"
        };

        foreach (string candidate in candidates)
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            int found = lower.IndexOf(candidate, StringComparison.OrdinalIgnoreCase);
            if (found >= 0)
            {
                index = found;
                length = candidate.Length;
                return true;
            }
        }
        return false;
    }

    private static string Normalize(string value)
    {
        StringBuilder sb = new StringBuilder(value.Length);
        foreach (char c in value) sb.Append(char.IsLetterOrDigit(c) ? char.ToLowerInvariant(c) : ' ');
        return string.Join(" ", sb.ToString().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
    }

    private static string J(string value)
    {
        return (value ?? string.Empty)
            .Replace("\\", "\\\\")
            .Replace("\"", "\\\"")
            .Replace("\n", "\\n")
            .Replace("\r", "\\r")
            .Replace("\t", "\\t");
    }

    private static string ExtractContent(string json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;

        int key = json.IndexOf("\"content\"", StringComparison.Ordinal);
        if (key < 0) return null;
        int colon = json.IndexOf(':', key + 9);
        if (colon < 0) return null;

        int start = colon + 1;
        while (start < json.Length && char.IsWhiteSpace(json[start])) start++;
        if (start >= json.Length || json[start] != '\"') return null;
        start++;

        StringBuilder sb = new StringBuilder();
        bool escaped = false;
        for (int i = start; i < json.Length; i++)
        {
            char c = json[i];
            if (escaped)
            {
                switch (c)
                {
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case '\"': sb.Append('\"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'u':
                        if (i + 4 < json.Length)
                        {
                            string hex = json.Substring(i + 1, 4);
                            int code;
                            if (int.TryParse(hex, System.Globalization.NumberStyles.HexNumber, null, out code))
                            {
                                sb.Append((char)code);
                                i += 4;
                            }
                        }
                        break;
                    default: sb.Append(c); break;
                }
                escaped = false;
                continue;
            }

            if (c == '\\')
            {
                escaped = true;
                continue;
            }
            if (c == '\"') break;
            sb.Append(c);
        }
        return sb.Length > 0 ? sb.ToString() : null;
    }

    private void ScheduleSpeechRestart()
    {
        if (_speechRestart == null && !_stoppingSpeech && _enabled.Value)
            _speechRestart = StartCoroutine(RestartSpeechRecognition());
    }

    private IEnumerator RestartSpeechRecognition()
    {
        yield return new WaitForSecondsRealtime(Mathf.Min(_restartDelay, 5f));
        _speechRestart = null;
        if (_stoppingSpeech || !_enabled.Value) yield break;

        try { StartSpeechBridge(); }
        catch (Exception ex)
        {
            Logger.LogWarning("Speech restart failed: " + ex.Message);
            _restartDelay = Mathf.Min(_restartDelay * 2f, MaxRestartDelay);
            ShowSpeechWarning();
            ScheduleSpeechRestart();
        }
    }

    private void StopSpeechRecognition()
    {
        _stoppingSpeech = true;
        if (_speechRestart != null)
        {
            StopCoroutine(_speechRestart);
            _speechRestart = null;
        }
        StopSpeechBridgeOnly();
    }

    private void StopSpeechBridgeOnly()
    {
        if (_speechBridge == null) return;
        try { _speechBridge.Dispose(); } catch { }
        _speechBridge = null;
    }

    private void ShowSpeechWarning()
    {
        _showDesktopSpeechWarning = true;
        Logger.LogWarning("HeySiri microphone recognition is unavailable. Press F2 and type to Siri, or check Windows microphone/speech settings.");
    }

    private void HideSpeechWarning()
    {
        _showDesktopSpeechWarning = false;
    }

    private void EnsureGuiStyles()
    {
        if (_panelGradient != null) return;

        _panelGradient = CreateGradientTexture(256, 256,
            new Color(0.018f, 0.08f, 0.23f, 0.985f),
            new Color(0.02f, 0.40f, 0.63f, 0.985f),
            new Color(0.35f, 0.12f, 0.55f, 0.985f));
        _panelShadow = MakeSolidTexture(new Color(0f, 0f, 0f, 0.58f));
        _buttonTex = CreateRoundedTexture(128, 48, new Color(0.02f, 0.15f, 0.34f, 0.97f), 12);
        _buttonHoverTex = CreateRoundedTexture(128, 48, new Color(0.03f, 0.55f, 0.76f, 0.99f), 12);
        _fieldTex = CreateRoundedTexture(256, 48, new Color(0.008f, 0.035f, 0.11f, 0.94f), 12);
        _cyanTex = CreateRoundedTexture(128, 48, new Color(0.09f, 0.88f, 1f, 0.98f), 12);
        _siriBadgeTex = CreateSiriBadgeTexture(96);

        _titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 31,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = Color.white }
        };
        _subtitleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(0.77f, 0.95f, 1f, 1f) }
        };
        _statusStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 11,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(0.84f, 0.98f, 1f, 1f) }
        };
        _labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            normal = { textColor = Color.white }
        };
        _fieldStyle = new GUIStyle(GUI.skin.textField)
        {
            fontSize = 16,
            padding = new RectOffset(14, 14, 8, 8),
            normal = { background = _fieldTex, textColor = Color.white },
            focused = { background = _fieldTex, textColor = Color.white }
        };
        _buttonStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize = 14,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter,
            normal = { background = _buttonTex, textColor = Color.white },
            hover = { background = _buttonHoverTex, textColor = Color.white },
            active = { background = _cyanTex, textColor = new Color(0.01f, 0.04f, 0.10f, 1f) }
        };
        _smallButtonStyle = new GUIStyle(_buttonStyle) { fontSize = 12 };
    }

    private static Texture2D MakeSolidTexture(Color color)
    {
        Texture2D tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        tex.hideFlags = HideFlags.HideAndDontSave;
        tex.SetPixel(0, 0, color);
        tex.Apply();
        return tex;
    }

    private static Texture2D CreateGradientTexture(int width, int height, Color topLeft, Color topRight, Color bottom)
    {
        Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
        tex.hideFlags = HideFlags.HideAndDontSave;
        Color[] pixels = new Color[width * height];
        for (int y = 0; y < height; y++)
        {
            float fy = y / (float)(height - 1);
            for (int x = 0; x < width; x++)
            {
                float fx = x / (float)(width - 1);
                Color top = Color.Lerp(topLeft, topRight, fx);
                pixels[y * width + x] = Color.Lerp(bottom, top, fy);
            }
        }
        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }

    private static Texture2D CreateRoundedTexture(int width, int height, Color color, int radius)
    {
        Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
        tex.hideFlags = HideFlags.HideAndDontSave;
        Color clear = new Color(0f, 0f, 0f, 0f);
        Color[] pixels = new Color[width * height];
        float r = Mathf.Max(1f, radius);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                float dx = Mathf.Max(Mathf.Max(r - x, x - (width - 1 - r)), 0f);
                float dy = Mathf.Max(Mathf.Max(r - y, y - (height - 1 - r)), 0f);
                bool inside = dx * dx + dy * dy <= r * r;
                pixels[y * width + x] = inside ? color : clear;
            }
        }

        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }

    private static Texture2D CreateSiriBadgeTexture(int size)
    {
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.hideFlags = HideFlags.HideAndDontSave;
        Color[] pixels = new Color[size * size];
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float radius = size * 0.47f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                Vector2 d = new Vector2(x, y) - center;
                float dist = d.magnitude;
                if (dist > radius)
                {
                    pixels[y * size + x] = Color.clear;
                    continue;
                }

                float angle = Mathf.Atan2(d.y, d.x);
                float n = Mathf.Clamp01(dist / radius);
                Color cyan = new Color(0.04f, 0.90f, 1f, 1f);
                Color purple = new Color(0.54f, 0.17f, 0.95f, 1f);
                Color pink = new Color(1f, 0.10f, 0.60f, 1f);
                Color edge = Color.Lerp(cyan, pink, 0.5f + 0.5f * Mathf.Sin(angle * 1.7f));
                edge = Color.Lerp(edge, purple, 0.35f + 0.25f * Mathf.Sin(angle * 2.3f + 1f));
                Color c = Color.Lerp(new Color(0.005f, 0.02f, 0.08f, 1f), edge, Mathf.Pow(n, 1.6f));

                float star = Mathf.Abs(Mathf.Sin(angle * 2f));
                if (n < 0.55f && star > 0.82f)
                    c = Color.Lerp(c, Color.white, (1f - n / 0.55f) * 0.78f);

                pixels[y * size + x] = c;
            }
        }

        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }

    private void OnGUI()
    {
        EnsureGuiStyles();

        if (_showDesktopSpeechWarning && !_showPcPanel)
        {
            GUIStyle warning = new GUIStyle(GUI.skin.box)
            {
                fontSize = 14,
                alignment = TextAnchor.MiddleCenter,
                wordWrap = true,
                normal = { textColor = Color.white, background = _buttonTex }
            };
            GUI.Box(new Rect(20f, 20f, 540f, 54f),
                "HeySiri microphone recognition is offline. Press F2 to type to Siri or check Windows microphone permissions.", warning);
        }

        if (_panelAnim <= 0.01f) return;

        float oldAlpha = GUI.color.a;
        GUI.color = new Color(1f, 1f, 1f, _panelAnim);

        float width = 650f;
        float height = 438f;
        float x = Mathf.Lerp(-width - 30f, 24f, Mathf.SmoothStep(0f, 1f, _panelAnim));
        float y = 24f;
        Rect shadow = new Rect(x + 9f, y + 10f, width, height);
        Rect panel = new Rect(x, y, width, height);
        GUI.DrawTexture(shadow, _panelShadow, ScaleMode.StretchToFill);
        GUI.DrawTexture(panel, _panelGradient, ScaleMode.StretchToFill);

        GUI.Label(new Rect(x + 28f, y + 18f, 430f, 42f), "HeySiri", _titleStyle);
        if (_siriBadgeTex != null) GUI.DrawTexture(new Rect(x + width - 104f, y + 16f, 76f, 76f), _siriBadgeTex, ScaleMode.ScaleToFit, true);
        GUI.Label(new Rect(x + 30f, y + 62f, width - 60f, 24f), _pcStatus, _statusStyle);

        GUI.SetNextControlName("HeySiriText");
        _pcInput = GUI.TextField(new Rect(x + 30f, y + 103f, width - 60f, 42f), _pcInput ?? string.Empty, 700, _fieldStyle);

        if (GUI.Button(new Rect(x + 30f, y + 159f, 118f, 38f), "SEND", _buttonStyle)) SendPcText();
        if (GUI.Button(new Rect(x + 158f, y + 159f, 118f, 38f), "WAKE  H", _buttonStyle)) ManualWake();
        if (GUI.Button(new Rect(x + 286f, y + 159f, 118f, 38f), "RECALL  B", _buttonStyle)) _orb?.Recall(false);
        if (GUI.Button(new Rect(x + 414f, y + 159f, 96f, 38f), _muted ? "UNMUTE" : "MUTE", _buttonStyle))
        {
            _muted = !_muted;
            _orb?.SetMuted(_muted);
        }
        if (GUI.Button(new Rect(x + 520f, y + 159f, 100f, 38f), "CLOSE", _buttonStyle)) TogglePcPanel();

        GUI.Label(new Rect(x + 30f, y + 216f, width - 60f, 22f), "SIRI MODE", _labelStyle);
        SiriMode mode = GetSiriMode();
        if (GUI.Button(new Rect(x + 30f, y + 243f, 185f, 38f), mode == SiriMode.Normal ? "NORMAL  ✓" : "NORMAL", _buttonStyle)) SetSiriMode(SiriMode.Normal);
        if (GUI.Button(new Rect(x + 232f, y + 243f, 185f, 38f), mode == SiriMode.Evil ? "EVIL  ✓" : "EVIL", _buttonStyle)) SetSiriMode(SiriMode.Evil);
        if (GUI.Button(new Rect(x + 434f, y + 243f, 186f, 38f), mode == SiriMode.Rizzy ? "RIZZY  ✓" : "RIZZY", _buttonStyle)) SetSiriMode(SiriMode.Rizzy);

        if (GUI.Button(new Rect(x + 30f, y + 300f, 132f, 34f), _orb != null && _orb.WantsVisible ? "HIDE ORB" : "SHOW ORB", _smallButtonStyle)) _orb?.ToggleVisible();
        if (GUI.Button(new Rect(x + 172f, y + 300f, 132f, 34f), _speechTextEnabled.Value ? "TEXT OFF" : "TEXT ON", _smallButtonStyle)) SetSpeechTextEnabled(!_speechTextEnabled.Value);
        if (GUI.Button(new Rect(x + 314f, y + 300f, 132f, 34f), "TEST VOICE", _smallButtonStyle)) StartCoroutine(SpeakReaction(GetWakeGreeting()));
        if (GUI.Button(new Rect(x + 456f, y + 300f, 164f, 34f), "CLEAR CHAT", _smallButtonStyle))
        {
            _history.Clear();
            _orb?.ShowBubble("Conversation cleared.", 2f);
        }

        if (GUI.Button(new Rect(x + 30f, y + 348f, 132f, 34f), "LISTEN NOW", _smallButtonStyle)) ManualWake();
        if (GUI.Button(new Rect(x + 172f, y + 348f, 132f, 34f), "COMMANDS", _smallButtonStyle))
            _orb?.ShowBubble("normal siri • evil siri • rizzy siri • recall • mute • text on/off", 7f);

        GUI.Label(new Rect(x + 30f, y + 398f, width - 150f, 22f),
            "H wake   B recall   F2 panel   Right-click drag + release to throw", _subtitleStyle);
        GUI.Label(new Rect(x + width - 120f, y + 398f, 90f, 22f), "v" + PluginInfo.Version, _subtitleStyle);

        Event e = Event.current;
        if (e != null && e.type == EventType.KeyDown && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
        {
            SendPcText();
            e.Use();
        }

        GUI.color = new Color(1f, 1f, 1f, oldAlpha);
    }

    private void DestroyGuiTextures()
    {
        foreach (Texture2D tex in new[] { _panelGradient, _panelShadow, _buttonTex, _buttonHoverTex, _fieldTex, _cyanTex, _siriBadgeTex })
        {
            if (tex != null) Object.Destroy(tex);
        }
    }

    private void OnDestroy()
    {
        RestoreCursor();
        StopSpeechRecognition();
        DestroyGuiTextures();
        if (_orb != null) Object.Destroy(_orb.gameObject);
        if (ReferenceEquals(Instance, this)) Instance = null;
    }
}
