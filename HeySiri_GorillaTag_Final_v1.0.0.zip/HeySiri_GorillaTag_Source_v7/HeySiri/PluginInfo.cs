namespace HeySiri;

public static class PluginInfo
{
    public const string Guid = "org.heysiri.gorillatag";
    public const string Name = "HeySiri";
    public const string Version = "1.0.0";
}
