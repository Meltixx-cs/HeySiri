using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace HeySiri;

public enum SiriOrbState
{
    Idle,
    Listening,
    Thinking,
    Talking,
    Grabbed,
    Thrown
}

public sealed class SiriOrbController : MonoBehaviour
{
    private sealed class WaveRibbon
    {
        public LineRenderer Line;
        public Transform Transform;
        public float Radius;
        public float Depth;
        public float Speed;
        public float Phase;
        public float Wobble;
        public int Harmonic;
    }

    private sealed class OrbitNode
    {
        public Transform Transform;
        public float Radius;
        public float Speed;
        public float Phase;
        public float Vertical;
    }

    private sealed class SiriPetal
    {
        public LineRenderer Line;
        public Transform Transform;
        public float Angle;
        public float Length;
        public float Curve;
        public float Phase;
        public float BaseWidth;
        public float Depth;
    }

    private readonly List<WaveRibbon> _ribbons = new List<WaveRibbon>();
    private readonly List<OrbitNode> _nodes = new List<OrbitNode>();
    private readonly List<SiriPetal> _petals = new List<SiriPetal>();
    private readonly float[] _audioSamples = new float[128];

    private Rigidbody _rigidbody;
    private SphereCollider _collider;
    private Transform _visualRoot;
    private Transform _core;
    private Transform _logoRoot;
    private Transform _highlight;
    private Transform _referenceFace;
    private Renderer _referenceFaceRenderer;
    private Material _referenceFaceMaterial;
    private Texture2D _referenceTexture;
    private LineRenderer _outerRing;
    private LineRenderer _innerRing;
    private float _outerRingRadius = 0.0615f;
    private float _innerRingRadius = 0.0525f;
    private Canvas _bubbleCanvas;
    private Text _bubbleText;
    private Image _bubbleBackground;
    private AudioSource _audio;
    private Camera _head;

    private SiriOrbState _state = SiriOrbState.Idle;
    private bool _grabbed;
    private bool _thrown;
    private bool _grabbedRight;
    private bool _desktopGrab;
    private bool _placedOnce;
    private bool _wantedVisible;
    private bool _startHidden = true;
    private Transform _grabHand;
    private Vector3 _lastHandPosition;
    private Vector3 _smoothedHandVelocity;
    private Vector3 _desktopLastWorld;
    private Vector3 _desktopVelocity;
    private float _desktopDepth;
    private float _grabStartedAt;
    private float _bubbleHideAt;
    private float _lastImpactAt = -10f;
    private float _recallFlash;
    private float _thrownAt;
    private float _visibility;
    private float _spawnBurst;
    private float _audioEnvelope;
    private bool _bubbleEnabled = true;

    private float _baseScale = 0.12f;
    private float _grabDistance = 0.22f;
    private float _throwMultiplier = 1.25f;
    private float _headDistance = 0.90f;
    private float _screenX = 0.82f;
    private float _screenY = 0.73f;
    private float _followSmooth = 20f;

    private readonly Color _cyan = new Color(0.12f, 0.94f, 1.00f, 1f);
    private readonly Color _blue = new Color(0.10f, 0.42f, 1.00f, 1f);
    private readonly Color _purple = new Color(0.58f, 0.22f, 1.00f, 1f);
    private readonly Color _magenta = new Color(0.95f, 0.14f, 0.80f, 1f);
    private readonly Color _pink = new Color(1.00f, 0.30f, 0.64f, 1f);

    public SiriOrbState State => _state;
    public bool IsGrabbed => _grabbed;
    public bool IsThrown => _thrown;
    public bool IsVisible => _visualRoot != null && _visualRoot.gameObject.activeSelf && _visibility > 0.05f;
    public bool WantsVisible => _wantedVisible;
    public AudioSource Audio => _audio;

    public static SiriOrbController Create(
        float baseScale,
        float grabDistance,
        float throwMultiplier,
        float headDistance,
        float screenX,
        float screenY,
        float followSmooth,
        bool startHidden)
    {
        GameObject root = new GameObject("HeySiri_Orb");
        Object.DontDestroyOnLoad(root);
        SiriOrbController controller = root.AddComponent<SiriOrbController>();
        controller._baseScale = Mathf.Clamp(baseScale, 0.07f, 0.22f);
        controller._grabDistance = Mathf.Clamp(grabDistance, 0.10f, 0.60f);
        controller._throwMultiplier = Mathf.Clamp(throwMultiplier, 0.25f, 3f);
        controller._headDistance = Mathf.Clamp(headDistance, 0.55f, 1.80f);
        controller._screenX = Mathf.Clamp(screenX, 0.58f, 0.94f);
        controller._screenY = Mathf.Clamp(screenY, 0.54f, 0.92f);
        controller._followSmooth = Mathf.Clamp(followSmooth, 2f, 45f);
        controller._startHidden = startHidden;
        controller._wantedVisible = !startHidden;
        controller.BuildOrb();
        return controller;
    }

    private void BuildOrb()
    {
        _rigidbody = gameObject.AddComponent<Rigidbody>();
        _rigidbody.useGravity = false;
        _rigidbody.isKinematic = true;
        _rigidbody.mass = 0.12f;
        _rigidbody.linearDamping = 0.35f;
        _rigidbody.angularDamping = 0.24f;
        _rigidbody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

        _collider = gameObject.AddComponent<SphereCollider>();
        _collider.radius = 0.075f;
        _collider.enabled = false;
        _collider.material = new PhysicsMaterial("HeySiri_Bouncy")
        {
            bounciness = 0.58f,
            dynamicFriction = 0.06f,
            staticFriction = 0.06f,
            bounceCombine = PhysicsMaterialCombine.Maximum,
            frictionCombine = PhysicsMaterialCombine.Minimum
        };

        _visualRoot = new GameObject("Visuals").transform;
        _visualRoot.SetParent(transform, false);
        _visualRoot.gameObject.SetActive(false);

        Shader unlit = FindUnlitShader();

        // The body stays dark and stable. The colored motion lives on the front face,
        // closer to the classic Siri visual than a generic rainbow sphere.
        _core = CreateSphere("SiriGlass", _visualRoot, 0.112f, new Color(0.008f, 0.018f, 0.055f, 1f), unlit);

        _logoRoot = new GameObject("SiriFace").transform;
        _logoRoot.SetParent(_visualRoot, false);
        _logoRoot.localPosition = Vector3.zero;

        _outerRing = CreateRing(
            "OuterGlow",
            _logoRoot,
            _outerRingRadius,
            0.0042f,
            0.058f,
            new[] { _pink, _purple, _blue, _cyan, _pink },
            unlit);

        _innerRing = CreateRing(
            "InnerGlow",
            _logoRoot,
            _innerRingRadius,
            0.0018f,
            0.059f,
            new[]
            {
                new Color(0.70f, 0.92f, 1f, 1f),
                _cyan,
                _purple,
                _pink,
                new Color(0.70f, 0.92f, 1f, 1f)
            },
            unlit);

        BuildSiriLogo(unlit);
        BuildReferenceFace();

        BuildSpeechBubble();

        _audio = gameObject.AddComponent<AudioSource>();
        _audio.playOnAwake = false;
        _audio.spatialBlend = 0f;
        _audio.volume = 1f;
        _audio.priority = 0;
        _audio.ignoreListenerPause = true;
        _audio.bypassEffects = true;
        _audio.bypassListenerEffects = true;
        _audio.bypassReverbZones = true;

        TryIgnoreLocalPlayerCollisions();
        SetState(SiriOrbState.Idle);
    }

    private static Shader FindUnlitShader()
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader != null) return shader;
        shader = Shader.Find("Unlit/Color");
        if (shader != null) return shader;
        shader = Shader.Find("Sprites/Default");
        if (shader != null) return shader;
        return Shader.Find("Standard");
    }

    private static Material MakeMaterial(string name, Color color, Shader shader)
    {
        Material material = new Material(shader) { name = name };
        if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        else material.color = color;
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        if (material.HasProperty("_EmissionColor"))
        {
            material.EnableKeyword("_EMISSION");
            material.SetColor("_EmissionColor", color * 0.82f);
        }
        return material;
    }

    private static Transform CreateSphere(string name, Transform parent, float diameter, Color color, Shader shader)
    {
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.name = name;
        sphere.transform.SetParent(parent, false);
        sphere.transform.localScale = Vector3.one * diameter;

        Collider primitiveCollider = sphere.GetComponent<Collider>();
        if (primitiveCollider != null) Object.Destroy(primitiveCollider);

        Renderer renderer = sphere.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.material = MakeMaterial(name + "_Mat", color, shader);
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }
        return sphere.transform;
    }

    private void CreateWaveRibbon(
        string name,
        Quaternion rotation,
        float radius,
        float width,
        float depth,
        float speed,
        float phase,
        float wobble,
        int harmonic,
        Shader shader)
    {
        GameObject waveObject = new GameObject(name);
        waveObject.transform.SetParent(_visualRoot, false);
        waveObject.transform.localRotation = rotation;

        LineRenderer line = waveObject.AddComponent<LineRenderer>();
        line.useWorldSpace = false;
        line.loop = true;
        line.positionCount = 96;
        line.widthMultiplier = width;
        line.numCornerVertices = 5;
        line.numCapVertices = 5;
        line.shadowCastingMode = ShadowCastingMode.Off;
        line.receiveShadows = false;
        line.material = MakeMaterial(name + "_Mat", Color.white, shader);

        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[]
            {
                new GradientColorKey(_cyan, 0f),
                new GradientColorKey(_blue, 0.20f),
                new GradientColorKey(_purple, 0.43f),
                new GradientColorKey(_magenta, 0.66f),
                new GradientColorKey(_pink, 0.82f),
                new GradientColorKey(_cyan, 1f)
            },
            new[]
            {
                new GradientAlphaKey(0.95f, 0f),
                new GradientAlphaKey(1f, 0.5f),
                new GradientAlphaKey(0.95f, 1f)
            });
        line.colorGradient = gradient;

        WaveRibbon ribbon = new WaveRibbon
        {
            Line = line,
            Transform = waveObject.transform,
            Radius = radius,
            Depth = depth,
            Speed = speed,
            Phase = phase,
            Wobble = wobble,
            Harmonic = harmonic
        };
        _ribbons.Add(ribbon);
        UpdateRibbon(ribbon, 0f, 1f, 0f, 0f);
    }

    private LineRenderer CreateRing(
        string name,
        Transform parent,
        float radius,
        float width,
        float z,
        Color[] colors,
        Shader shader)
    {
        GameObject ringObject = new GameObject(name);
        ringObject.transform.SetParent(parent, false);

        LineRenderer line = ringObject.AddComponent<LineRenderer>();
        line.useWorldSpace = false;
        line.loop = true;
        line.positionCount = 96;
        line.widthMultiplier = width;
        line.numCornerVertices = 6;
        line.numCapVertices = 6;
        line.shadowCastingMode = ShadowCastingMode.Off;
        line.receiveShadows = false;
        line.material = MakeMaterial(name + "_Mat", Color.white, shader);

        Gradient gradient = new Gradient();
        GradientColorKey[] colorKeys = new GradientColorKey[colors.Length];
        for (int i = 0; i < colors.Length; i++)
            colorKeys[i] = new GradientColorKey(colors[i], i / (float)(colors.Length - 1));
        gradient.SetKeys(
            colorKeys,
            new[]
            {
                new GradientAlphaKey(0.95f, 0f),
                new GradientAlphaKey(1f, 0.5f),
                new GradientAlphaKey(0.95f, 1f)
            });
        line.colorGradient = gradient;

        for (int i = 0; i < line.positionCount; i++)
        {
            float a = i / (float)line.positionCount * Mathf.PI * 2f;
            line.SetPosition(i, new Vector3(Mathf.Cos(a) * radius, Mathf.Sin(a) * radius, z));
        }

        return line;
    }

    private static Shader FindTransparentShader()
    {
        Shader shader = Shader.Find("Sprites/Default");
        if (shader != null) return shader;
        shader = Shader.Find("Unlit/Transparent");
        if (shader != null) return shader;
        shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader != null) return shader;
        return FindUnlitShader();
    }

    private static Texture2D LoadEmbeddedTexture(string resourceName)
    {
        try
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                if (stream == null) return null;
                byte[] bytes = new byte[stream.Length];
                int offset = 0;
                while (offset < bytes.Length)
                {
                    int read = stream.Read(bytes, offset, bytes.Length - offset);
                    if (read <= 0) break;
                    offset += read;
                }

                Texture2D texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                texture.name = "HeySiri_SiriIdle";
                texture.wrapMode = TextureWrapMode.Clamp;
                texture.filterMode = FilterMode.Bilinear;
                if (!ImageConversion.LoadImage(texture, bytes, false))
                {
                    Object.Destroy(texture);
                    return null;
                }
                return texture;
            }
        }
        catch
        {
            return null;
        }
    }

    private void BuildReferenceFace()
    {
        _referenceTexture = LoadEmbeddedTexture("HeySiri.Assets.SiriIdle.png");
        if (_referenceTexture == null) return;

        GameObject face = GameObject.CreatePrimitive(PrimitiveType.Quad);
        face.name = "SiriReferenceFace";
        face.transform.SetParent(_logoRoot, false);
        face.transform.localPosition = new Vector3(0f, 0f, 0.0665f);
        face.transform.localRotation = Quaternion.identity;
        face.transform.localScale = new Vector3(0.142f, 0.142f, 1f);

        Collider collider = face.GetComponent<Collider>();
        if (collider != null) Object.Destroy(collider);

        _referenceFaceRenderer = face.GetComponent<Renderer>();
        if (_referenceFaceRenderer != null)
        {
            Shader shader = FindTransparentShader();
            _referenceFaceMaterial = new Material(shader) { name = "HeySiri_ReferenceFace_Mat" };
            if (_referenceFaceMaterial.HasProperty("_MainTex")) _referenceFaceMaterial.SetTexture("_MainTex", _referenceTexture);
            if (_referenceFaceMaterial.HasProperty("_BaseMap")) _referenceFaceMaterial.SetTexture("_BaseMap", _referenceTexture);
            if (_referenceFaceMaterial.HasProperty("_Color")) _referenceFaceMaterial.SetColor("_Color", Color.white);
            if (_referenceFaceMaterial.HasProperty("_BaseColor")) _referenceFaceMaterial.SetColor("_BaseColor", Color.white);
            _referenceFaceMaterial.renderQueue = 3100;
            _referenceFaceRenderer.material = _referenceFaceMaterial;
            _referenceFaceRenderer.shadowCastingMode = ShadowCastingMode.Off;
            _referenceFaceRenderer.receiveShadows = false;
        }

        _referenceFace = face.transform;
    }

    private void BuildSiriLogo(Shader shader)
    {
        Color softWhite = new Color(0.97f, 0.99f, 1f, 1f);

        // Five larger, softer sweeps read more like the familiar Siri idle symbol.
        CreateLogoPetal(-22f, _cyan, 0.060f, 0.020f, 0.018f, 0.0f, 0.0610f, shader);
        CreateLogoPetal(52f, _pink, 0.058f, -0.018f, 0.0175f, 0.8f, 0.0612f, shader);
        CreateLogoPetal(128f, _purple, 0.053f, 0.017f, 0.0165f, 1.6f, 0.0614f, shader);
        CreateLogoPetal(206f, _blue, 0.056f, -0.018f, 0.0170f, 2.4f, 0.0616f, shader);
        CreateLogoPetal(292f, _cyan, 0.057f, 0.019f, 0.0170f, 3.2f, 0.0618f, shader);

        // Bright star centre.
        CreateLogoPetal(16f, softWhite, 0.040f, 0.004f, 0.0108f, 0.15f, 0.0632f, shader);
        CreateLogoPetal(104f, softWhite, 0.036f, -0.004f, 0.0102f, 1.15f, 0.0636f, shader);
        CreateLogoPetal(198f, softWhite, 0.039f, 0.004f, 0.0102f, 2.15f, 0.0640f, shader);
        CreateLogoPetal(288f, softWhite, 0.036f, -0.004f, 0.0102f, 3.15f, 0.0644f, shader);

        _highlight = CreateSphere(
            "GlassHighlight",
            _logoRoot,
            0.015f,
            new Color(0.78f, 0.97f, 1f, 1f),
            shader);
        _highlight.localPosition = new Vector3(-0.025f, 0.028f, 0.055f);
        _highlight.localScale = new Vector3(0.018f, 0.009f, 0.004f);
    }

    private void CreateLogoPetal(
        float angle,
        Color tipColor,
        float length,
        float curve,
        float width,
        float phase,
        float depth,
        Shader shader)
    {
        GameObject petalObject = new GameObject("Petal_" + _petals.Count);
        petalObject.transform.SetParent(_logoRoot, false);

        LineRenderer line = petalObject.AddComponent<LineRenderer>();
        line.useWorldSpace = false;
        line.loop = false;
        line.positionCount = 28;
        line.widthMultiplier = width;
        line.numCornerVertices = 8;
        line.numCapVertices = 8;
        line.shadowCastingMode = ShadowCastingMode.Off;
        line.receiveShadows = false;
        line.material = MakeMaterial("PetalMat_" + _petals.Count, Color.white, shader);
        line.widthCurve = new AnimationCurve(
            new Keyframe(0f, 0.18f),
            new Keyframe(0.18f, 0.95f),
            new Keyframe(0.46f, 1.15f),
            new Keyframe(0.78f, 0.55f),
            new Keyframe(1f, 0.05f));

        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[]
            {
                new GradientColorKey(new Color(0.96f, 1f, 1f, 1f), 0f),
                new GradientColorKey(Color.Lerp(Color.white, tipColor, 0.45f), 0.28f),
                new GradientColorKey(tipColor, 1f)
            },
            new[]
            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 0.55f),
                new GradientAlphaKey(0.90f, 1f)
            });
        line.colorGradient = gradient;

        SiriPetal petal = new SiriPetal
        {
            Line = line,
            Transform = petalObject.transform,
            Angle = angle,
            Length = length,
            Curve = curve,
            Phase = phase,
            BaseWidth = width,
            Depth = depth
        };
        _petals.Add(petal);
        UpdateLogoPetal(petal, 0f, 0f, 0.85f);
    }

    private static void UpdateReactiveRing(LineRenderer line, float radius, float width, float z, float time, float voiceEnergy, float idleRipple, float phaseOffset)
    {
        if (line == null) return;
        int count = line.positionCount;
        for (int i = 0; i < count; i++)
        {
            float u = i / (float)count;
            float angle = u * Mathf.PI * 2f;
            float bumps = Mathf.Sin(angle * 6f + time * 6.5f + phaseOffset) * (voiceEnergy * 0.0105f + idleRipple * 0.0007f);
            bumps += Mathf.Sin(angle * 12f - time * 4.2f + phaseOffset * 0.7f) * (voiceEnergy * 0.0046f);
            float r = radius + bumps;
            line.SetPosition(i, new Vector3(Mathf.Cos(angle) * r, Mathf.Sin(angle) * r, z));
        }
        line.widthMultiplier = width * (1f + voiceEnergy * 0.55f);
    }

    private void UpdateLogo(float time, float activity, float audioPulse)
    {
        float talk = _state == SiriOrbState.Talking ? audioPulse : 0f;
        float listening = _state == SiriOrbState.Listening ? (0.5f + 0.5f * Mathf.Sin(time * 5f)) : 0f;
        float thinking = _state == SiriOrbState.Thinking ? (0.5f + 0.5f * Mathf.Sin(time * 7.5f)) : 0f;
        float voiceEnergy = Mathf.Clamp01(talk * 1.25f + listening * 0.18f + thinking * 0.12f);

        for (int i = 0; i < _petals.Count; i++)
        {
            SiriPetal petal = _petals[i];
            UpdateLogoPetal(petal, time, voiceEnergy, activity);
            petal.Line.widthMultiplier = petal.BaseWidth * (1f + voiceEnergy * 0.38f);
        }

        if (_outerRing != null)
        {
            float ringPulse = 1f + voiceEnergy * 0.03f + Mathf.Sin(time * 2.4f) * 0.004f;
            _outerRing.transform.localScale = Vector3.one * ringPulse;
            UpdateReactiveRing(_outerRing, _outerRingRadius, 0.0042f, 0.058f, time, voiceEnergy, 1f - Mathf.Clamp01(voiceEnergy), 0f);
        }

        if (_innerRing != null)
        {
            float spin = (_state == SiriOrbState.Thinking ? 42f : 10f) * Time.unscaledDeltaTime;
            _innerRing.transform.Rotate(0f, 0f, spin, Space.Self);
            UpdateReactiveRing(_innerRing, _innerRingRadius, 0.0018f, 0.059f, time, voiceEnergy * 0.8f, 0.7f, 1.4f);
        }

        if (_referenceFace != null)
        {
            float idleBreath = 1f + Mathf.Sin(time * 1.8f) * 0.008f;
            float voiceStretch = 1f + voiceEnergy * 0.055f;
            float sideStretch = 1f + voiceEnergy * 0.020f;
            _referenceFace.localScale = new Vector3(0.142f * sideStretch * idleBreath, 0.142f * voiceStretch * idleBreath, 1f);
            _referenceFace.localPosition = new Vector3(0f, voiceEnergy * 0.0025f, 0.0665f);
        }

        if (_highlight != null)
        {
            float h = 1f + voiceEnergy * 0.22f;
            _highlight.localScale = new Vector3(0.018f * h, 0.009f * h, 0.004f);
        }
    }

    private static void UpdateLogoPetal(SiriPetal petal, float time, float voiceEnergy, float activity)
    {
        if (petal == null || petal.Line == null) return;

        float angle = petal.Angle * Mathf.Deg2Rad;
        Vector2 dir = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
        Vector2 side = new Vector2(-dir.y, dir.x);
        float wave = Mathf.Sin(time * 7.5f + petal.Phase);
        float lengthScale = 1f + voiceEnergy * (0.10f + 0.08f * Mathf.Abs(wave));
        float curveScale = 1f + voiceEnergy * 0.75f;

        int count = petal.Line.positionCount;
        for (int i = 0; i < count; i++)
        {
            float u = i / (float)(count - 1);
            float eased = Mathf.SmoothStep(0f, 1f, u);
            float sideBend = Mathf.Sin(u * Mathf.PI) * petal.Curve * curveScale;
            sideBend += Mathf.Sin(time * 5.7f + petal.Phase + u * 4.5f) * voiceEnergy * 0.0038f * u;
            Vector2 p = dir * (petal.Length * eased * lengthScale) + side * sideBend;
            float z = petal.Depth + Mathf.Sin(u * Mathf.PI) * 0.0025f * activity;
            petal.Line.SetPosition(i, new Vector3(p.x, p.y, z));
        }
    }

    private void BuildSpeechBubble()
    {
        GameObject canvasObject = new GameObject("SpeechBubble");
        canvasObject.transform.SetParent(transform, false);
        canvasObject.transform.localPosition = new Vector3(-0.03f, 0.145f, 0f);

        _bubbleCanvas = canvasObject.AddComponent<Canvas>();
        _bubbleCanvas.renderMode = RenderMode.WorldSpace;
        _bubbleCanvas.sortingOrder = 2500;
        CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.dynamicPixelsPerUnit = 20f;

        RectTransform canvasRect = canvasObject.GetComponent<RectTransform>();
        canvasRect.sizeDelta = new Vector2(500f, 142f);
        canvasRect.localScale = Vector3.one * 0.00105f;

        GameObject backgroundObject = new GameObject("Background");
        backgroundObject.transform.SetParent(canvasObject.transform, false);
        _bubbleBackground = backgroundObject.AddComponent<Image>();
        _bubbleBackground.color = new Color(0.012f, 0.025f, 0.085f, 0.96f);
        RectTransform bgRect = backgroundObject.GetComponent<RectTransform>();
        bgRect.anchorMin = Vector2.zero;
        bgRect.anchorMax = Vector2.one;
        bgRect.offsetMin = Vector2.zero;
        bgRect.offsetMax = Vector2.zero;

        GameObject accentObject = new GameObject("Accent");
        accentObject.transform.SetParent(backgroundObject.transform, false);
        Image accent = accentObject.AddComponent<Image>();
        accent.color = _cyan;
        RectTransform accentRect = accentObject.GetComponent<RectTransform>();
        accentRect.anchorMin = new Vector2(0f, 0f);
        accentRect.anchorMax = new Vector2(0f, 1f);
        accentRect.pivot = new Vector2(0f, 0.5f);
        accentRect.sizeDelta = new Vector2(7f, 0f);
        accentRect.anchoredPosition = Vector2.zero;

        GameObject textObject = new GameObject("Text");
        textObject.transform.SetParent(backgroundObject.transform, false);
        _bubbleText = textObject.AddComponent<Text>();
        _bubbleText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        _bubbleText.fontSize = 30;
        _bubbleText.alignment = TextAnchor.MiddleCenter;
        _bubbleText.color = Color.white;
        _bubbleText.horizontalOverflow = HorizontalWrapMode.Wrap;
        _bubbleText.verticalOverflow = VerticalWrapMode.Truncate;
        _bubbleText.supportRichText = false;
        _bubbleText.resizeTextForBestFit = true;
        _bubbleText.resizeTextMinSize = 16;
        _bubbleText.resizeTextMaxSize = 30;

        Outline outline = textObject.AddComponent<Outline>();
        outline.effectColor = new Color(0f, 0f, 0f, 0.95f);
        outline.effectDistance = new Vector2(1.2f, -1.2f);

        RectTransform textRect = textObject.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(24f, 13f);
        textRect.offsetMax = new Vector2(-18f, -13f);

        canvasObject.SetActive(false);
    }

    private void Update()
    {
        Camera resolved = InputBridge.GetHeadCamera();
        if (resolved != _head)
        {
            _head = resolved;
            _placedOnce = false;
        }

        if (_head == null)
        {
            HideUntilCameraReady();
            return;
        }

        if (!_placedOnce)
        {
            PlaceAtDockInstantly();
            _placedOnce = true;
        }

        HandleRecallInput();
        HandleGrabInput();
        UpdatePlacement();
        AnimateOrb();
        UpdateBubble();
    }

    private void PlaceAtDockInstantly()
    {
        if (_head == null) return;
        transform.position = GetDockTarget();
        _rigidbody.isKinematic = true;
        _rigidbody.useGravity = false;
        _collider.enabled = false;
        if (!_startHidden && !_wantedVisible) _wantedVisible = true;
        if (_wantedVisible && _visualRoot != null) _visualRoot.gameObject.SetActive(true);
    }

    private void HideUntilCameraReady()
    {
        if (_visualRoot != null) _visualRoot.gameObject.SetActive(false);
        if (_bubbleCanvas != null) _bubbleCanvas.gameObject.SetActive(false);
        if (_collider != null) _collider.enabled = false;
    }

    private void HandleRecallInput()
    {
        if (InputBridge.RecallPressedThisFrame())
            Recall(false);
    }

    private void HandleGrabInput()
    {
        if (_head == null || !_wantedVisible || _visibility < 0.35f) return;

        if (_desktopGrab)
        {
            UpdateDesktopGrab();
            return;
        }

        if (_grabbed)
        {
            float grip = InputBridge.GetGrip(_grabbedRight);
            if (_grabHand == null || grip < 0.35f)
            {
                ReleaseFromHand();
                return;
            }

            float dt = Mathf.Max(Time.unscaledDeltaTime, 0.0001f);
            Vector3 current = _grabHand.position;
            Vector3 instantVelocity = (current - _lastHandPosition) / dt;
            _smoothedHandVelocity = Vector3.Lerp(_smoothedHandVelocity, instantVelocity, 0.35f);
            _lastHandPosition = current;
            transform.position = current + _grabHand.forward * 0.035f;
            return;
        }

        if (_thrown) return;
        if (TryBeginDesktopGrab()) return;
        TryBeginVrGrab(false);
        if (!_grabbed) TryBeginVrGrab(true);
    }

    private bool TryBeginDesktopGrab()
    {
        if (!InputBridge.IsDesktopRightMousePressedThisFrame() || _head == null)
            return false;

        Vector3 screen = _head.WorldToScreenPoint(transform.position);
        if (screen.z <= 0f) return false;

        Vector2 mouse = InputBridge.GetMousePosition();
        float pixelDistance = Vector2.Distance(mouse, new Vector2(screen.x, screen.y));
        if (pixelDistance > 110f) return false;

        _desktopGrab = true;
        _grabbed = true;
        _thrown = false;
        _wantedVisible = true;
        _grabStartedAt = Time.realtimeSinceStartup;
        _desktopDepth = Mathf.Clamp(screen.z, 0.55f, 2f);
        _desktopLastWorld = _head.ScreenToWorldPoint(new Vector3(mouse.x, mouse.y, _desktopDepth));
        _desktopVelocity = Vector3.zero;
        _rigidbody.isKinematic = true;
        _collider.enabled = false;
        SetState(SiriOrbState.Grabbed);
        ShowBubble("Careful 😭", 1.5f);
        return true;
    }

    private void UpdateDesktopGrab()
    {
        if (_head == null || InputBridge.IsDesktopRightMouseReleasedThisFrame() || !InputBridge.IsDesktopRightMouseHeld())
        {
            ReleaseDesktopGrab();
            return;
        }

        Vector2 mouse = InputBridge.GetMousePosition();
        Vector3 world = _head.ScreenToWorldPoint(new Vector3(mouse.x, mouse.y, _desktopDepth));
        float dt = Mathf.Max(Time.unscaledDeltaTime, 0.0001f);
        Vector3 smoothedTarget = Vector3.Lerp(transform.position, world, 1f - Mathf.Exp(-28f * dt));
        Vector3 instantVelocity = (smoothedTarget - _desktopLastWorld) / dt;
        _desktopVelocity = Vector3.Lerp(_desktopVelocity, instantVelocity, 0.36f);
        _desktopLastWorld = smoothedTarget;
        transform.position = smoothedTarget;
    }

    private void ReleaseDesktopGrab()
    {
        Vector3 throwVelocity = _desktopVelocity * (_throwMultiplier * 0.95f);
        _desktopGrab = false;
        _grabbed = false;
        BeginThrow(throwVelocity);
        if (Time.realtimeSinceStartup - _grabStartedAt > 0.08f && throwVelocity.magnitude > 0.8f)
            Plugin.Instance?.ReactToThrow(throwVelocity.magnitude);
    }

    private void TryBeginVrGrab(bool right)
    {
        if (InputBridge.GetGrip(right) < 0.65f) return;
        Transform hand = InputBridge.GetHand(right);
        if (hand == null) return;
        if (Vector3.Distance(hand.position, transform.position) > _grabDistance) return;

        _grabbed = true;
        _grabbedRight = right;
        _grabHand = hand;
        _lastHandPosition = hand.position;
        _smoothedHandVelocity = Vector3.zero;
        _grabStartedAt = Time.realtimeSinceStartup;
        _thrown = false;
        _wantedVisible = true;
        _rigidbody.isKinematic = true;
        _collider.enabled = false;
        _rigidbody.linearVelocity = Vector3.zero;
        _rigidbody.angularVelocity = Vector3.zero;
        SetState(SiriOrbState.Grabbed);
        ShowBubble("Hey—careful.", 1.5f);
    }

    private void ReleaseFromHand()
    {
        float heldFor = Time.realtimeSinceStartup - _grabStartedAt;
        Vector3 throwVelocity = _smoothedHandVelocity * _throwMultiplier;
        _grabbed = false;
        _grabHand = null;
        BeginThrow(throwVelocity);
        if (heldFor > 0.08f && throwVelocity.magnitude > 0.8f)
            Plugin.Instance?.ReactToThrow(throwVelocity.magnitude);
    }

    private void BeginThrow(Vector3 throwVelocity)
    {
        _thrown = true;
        _wantedVisible = true;
        _thrownAt = Time.realtimeSinceStartup;
        _rigidbody.isKinematic = false;
        _rigidbody.useGravity = false;
        _collider.enabled = true;
        _rigidbody.linearVelocity = throwVelocity;
        _rigidbody.angularVelocity = UnityEngine.Random.insideUnitSphere * Mathf.Clamp(throwVelocity.magnitude * 1.85f, 1.4f, 12f);
        SetState(SiriOrbState.Thrown);
    }

    private void UpdatePlacement()
    {
        if (_head == null || _grabbed) return;

        if (_thrown)
        {
            if (!_rigidbody.isKinematic)
                _rigidbody.linearVelocity *= Mathf.Pow(0.985f, Time.unscaledDeltaTime * 60f);

            float distance = Vector3.Distance(transform.position, _head.transform.position);
            if (distance > 8f || Time.realtimeSinceStartup - _thrownAt > 13f)
                Recall(false);
            return;
        }

        _rigidbody.isKinematic = true;
        _rigidbody.useGravity = false;
        _collider.enabled = false;
        Vector3 target = GetDockTarget();
        float lerp = 1f - Mathf.Exp(-_followSmooth * Time.unscaledDeltaTime);
        transform.position = Vector3.Lerp(transform.position, target, lerp);
    }

    private Vector3 GetDockTarget()
    {
        if (_head == null) return transform.position;
        return _head.ViewportToWorldPoint(new Vector3(_screenX, _screenY, _headDistance));
    }

    private void AnimateOrb()
    {
        if (_visualRoot == null) return;

        float visibilityTarget = (_wantedVisible || _grabbed || _thrown) ? 1f : 0f;
        float visibilitySpeed = visibilityTarget > _visibility ? 10f : 7f;
        _visibility = Mathf.MoveTowards(_visibility, visibilityTarget, Time.unscaledDeltaTime * visibilitySpeed);

        if (_visibility <= 0.005f && visibilityTarget <= 0f)
        {
            if (_visualRoot.gameObject.activeSelf) _visualRoot.gameObject.SetActive(false);
            return;
        }
        if (!_visualRoot.gameObject.activeSelf) _visualRoot.gameObject.SetActive(true);

        float t = Time.unscaledTime;
        float speed;
        float pulse;
        float activity;
        float audioPulse = GetAudioPulse();

        switch (_state)
        {
            case SiriOrbState.Listening:
                speed = 1.45f;
                activity = 1.25f;
                pulse = 1f + Mathf.Sin(t * 5.8f) * 0.070f;
                break;
            case SiriOrbState.Thinking:
                speed = 2.7f;
                activity = 1.40f;
                pulse = 1f + Mathf.Sin(t * 8.5f) * 0.045f;
                break;
            case SiriOrbState.Talking:
                speed = 2.05f + audioPulse * 0.8f;
                activity = 1.30f + audioPulse * 0.65f;
                pulse = 1f + audioPulse * 0.20f + Mathf.Sin(t * 7.0f) * 0.025f;
                break;
            case SiriOrbState.Grabbed:
                speed = 1.9f;
                activity = 1.15f;
                pulse = 1.05f;
                break;
            case SiriOrbState.Thrown:
                speed = 3.5f;
                activity = 1.55f;
                pulse = 1.02f + Mathf.Sin(t * 10f) * 0.04f;
                break;
            default:
                speed = 0.72f;
                activity = 0.82f;
                pulse = 1f + Mathf.Sin(t * 2.3f) * 0.028f;
                break;
        }

        if (_spawnBurst > 0f)
        {
            _spawnBurst = Mathf.Max(0f, _spawnBurst - Time.unscaledDeltaTime * 1.65f);
            pulse += Mathf.Sin((1f - _spawnBurst) * Mathf.PI) * _spawnBurst * 0.25f;
            activity += _spawnBurst * 0.7f;
        }
        if (_recallFlash > 0f)
        {
            _recallFlash -= Time.unscaledDeltaTime;
            pulse += Mathf.Clamp01(_recallFlash / 0.32f) * 0.22f;
        }

        float appearScale = Mathf.SmoothStep(0f, 1f, _visibility);
        float size = (_baseScale / 0.12f) * pulse * appearScale;
        _visualRoot.localScale = Vector3.one * size;

        if (_head != null)
        {
            Vector3 toCamera = _head.transform.position - transform.position;
            if (toCamera.sqrMagnitude > 0.001f)
            {
                float roll = _state == SiriOrbState.Thrown ? Mathf.Sin(t * 11f) * 9f : 0f;
                _visualRoot.rotation = Quaternion.LookRotation(toCamera.normalized, _head.transform.up) * Quaternion.Euler(0f, 0f, roll);
            }
        }

        // Siri rises and falls with speech instead of just changing color.
        float voiceBob = _state == SiriOrbState.Talking
            ? (Mathf.Sin(t * (8f + audioPulse * 6f)) * (0.003f + audioPulse * 0.012f))
            : Mathf.Sin(t * 2f) * 0.0015f;
        _visualRoot.localPosition = new Vector3(0f, voiceBob, 0f);

        UpdateLogo(t, activity, audioPulse);

        for (int i = 0; i < _ribbons.Count; i++)
        {
            WaveRibbon ribbon = _ribbons[i];
            float direction = (i % 2 == 0) ? 1f : -1f;
            UpdateRibbon(ribbon, t, activity, speed * direction, audioPulse);
            ribbon.Transform.Rotate(new Vector3(1.2f + i * 0.4f, 2.0f + i * 0.35f, 2.8f + i * 0.25f) * (speed * direction * Time.unscaledDeltaTime), Space.Self);
        }

        for (int i = 0; i < _nodes.Count; i++)
        {
            OrbitNode node = _nodes[i];
            float a = t * node.Speed * speed + node.Phase;
            node.Transform.localPosition = new Vector3(
                Mathf.Cos(a) * node.Radius,
                Mathf.Sin(a * 1.43f) * node.Vertical * activity,
                Mathf.Sin(a) * node.Radius);
            float nodePulse = 0.85f + 0.30f * Mathf.Sin(a * 1.9f) + audioPulse * 0.35f;
            node.Transform.localScale = Vector3.one * Mathf.Max(0.25f, nodePulse);
        }

        if (_core != null)
        {
            float corePulse = 1f + audioPulse * 0.22f + Mathf.Sin(t * 3f) * 0.03f;
            _core.localScale = Vector3.one * 0.112f * (1f + (corePulse - 1f) * 0.35f);
        }
    }

    private void UpdateRibbon(WaveRibbon ribbon, float time, float activity, float speed, float audioPulse)
    {
        if (ribbon == null || ribbon.Line == null) return;
        int count = ribbon.Line.positionCount;
        for (int i = 0; i < count; i++)
        {
            float theta = i / (float)count * Mathf.PI * 2f;
            float travel = time * ribbon.Speed * speed + ribbon.Phase;
            float voiceWave = Mathf.Sin(theta * ribbon.Harmonic + travel * 2.3f);
            float secondary = Mathf.Sin(theta * (ribbon.Harmonic + 2) - travel * 1.7f);
            float dynamicWobble = ribbon.Wobble * activity + audioPulse * 0.08f;
            float radial = ribbon.Radius * (1f + voiceWave * dynamicWobble + secondary * 0.035f * activity);
            float z = Mathf.Sin(theta * 2f + travel) * ribbon.Depth * activity
                    + Mathf.Cos(theta * 5f - travel * 0.7f) * ribbon.Depth * 0.22f;
            ribbon.Line.SetPosition(i, new Vector3(Mathf.Cos(theta) * radial, Mathf.Sin(theta) * radial, z));
        }
    }

    private float GetAudioPulse()
    {
        float target = 0f;
        if (_audio != null && _audio.isPlaying)
        {
            _audio.GetOutputData(_audioSamples, 0);
            float sum = 0f;
            for (int i = 0; i < _audioSamples.Length; i++)
                sum += _audioSamples[i] * _audioSamples[i];
            target = Mathf.Clamp01(Mathf.Sqrt(sum / _audioSamples.Length) * 12f);
        }

        float speed = target > _audioEnvelope ? 18f : 7f;
        _audioEnvelope = Mathf.MoveTowards(_audioEnvelope, target, Time.unscaledDeltaTime * speed);
        return _audioEnvelope;
    }

    private void UpdateBubble()
    {
        if (_bubbleCanvas == null) return;

        if (_bubbleCanvas.gameObject.activeSelf && _head != null)
        {
            Transform bubble = _bubbleCanvas.transform;
            Vector3 direction = bubble.position - _head.transform.position;
            if (direction.sqrMagnitude > 0.0001f)
                bubble.rotation = Quaternion.LookRotation(direction.normalized, _head.transform.up);
        }

        if (_bubbleHideAt > 0f && Time.realtimeSinceStartup >= _bubbleHideAt)
        {
            _bubbleHideAt = 0f;
            _bubbleCanvas.gameObject.SetActive(false);
        }

        if (_state == SiriOrbState.Talking && (_audio == null || !_audio.isPlaying))
        {
            if (_grabbed) _state = SiriOrbState.Grabbed;
            else if (_thrown) _state = SiriOrbState.Thrown;
            else _state = SiriOrbState.Idle;
        }
    }

    public void SetState(SiriOrbState state)
    {
        if (_grabbed && state != SiriOrbState.Grabbed) return;
        if (_thrown && state != SiriOrbState.Thrown && state != SiriOrbState.Talking) return;
        _state = state;
    }

    public void ShowBubble(string text, float seconds = 7f)
    {
        if (!_bubbleEnabled) return;
        if (_bubbleCanvas == null || _bubbleText == null) return;
        _bubbleText.text = text ?? string.Empty;
        if (_head != null && _wantedVisible) _bubbleCanvas.gameObject.SetActive(true);
        _bubbleHideAt = Time.realtimeSinceStartup + Mathf.Max(0.5f, seconds);
    }

    public void PlayClip(AudioClip clip)
    {
        if (_audio == null || clip == null) return;
        Awaken(false);
        _audio.Stop();
        _audio.clip = clip;
        _audio.Play();
        if (!_grabbed) _state = SiriOrbState.Talking;
    }

    public void SetBubbleEnabled(bool enabled)
    {
        _bubbleEnabled = enabled;
        if (!enabled && _bubbleCanvas != null)
            _bubbleCanvas.gameObject.SetActive(false);
    }

    public void SetMuted(bool muted)
    {
        if (_audio != null) _audio.mute = muted;
    }

    public void Awaken(bool instant)
    {
        bool wasHidden = !_wantedVisible || _visibility < 0.08f;
        _wantedVisible = true;
        if (_visualRoot != null) _visualRoot.gameObject.SetActive(true);
        if (instant) _visibility = 1f;
        else if (wasHidden) _spawnBurst = 1f;
        else _spawnBurst = Mathf.Max(_spawnBurst, 0.18f);
        if (_head != null && !_placedOnce) PlaceAtDockInstantly();
    }

    public void Sleep()
    {
        if (_grabbed || _thrown || (_audio != null && _audio.isPlaying)) return;
        _wantedVisible = false;
        if (_bubbleCanvas != null) _bubbleCanvas.gameObject.SetActive(false);
    }

    public void ToggleVisible()
    {
        if (_wantedVisible) Sleep();
        else
        {
            Recall(true);
            Awaken(false);
        }
    }

    public void Recall(bool instant, bool showBubble = true)
    {
        _grabbed = false;
        _desktopGrab = false;
        _thrown = false;
        _grabHand = null;
        _wantedVisible = true;

        if (_rigidbody != null)
        {
            _rigidbody.isKinematic = true;
            _rigidbody.useGravity = false;
            _rigidbody.linearVelocity = Vector3.zero;
            _rigidbody.angularVelocity = Vector3.zero;
        }
        if (_collider != null) _collider.enabled = false;

        _head = InputBridge.GetHeadCamera();
        if (_head != null)
        {
            transform.position = GetDockTarget();
            _placedOnce = true;
            if (_visualRoot != null) _visualRoot.gameObject.SetActive(true);
            if (instant) _visibility = 1f;
            else
            {
                _recallFlash = 0.32f;
                _spawnBurst = 0.75f;
                if (showBubble) ShowBubble("I'm back.", 1.3f);
            }
        }
        else HideUntilCameraReady();

        _state = SiriOrbState.Idle;
    }

    public void ForceListeningVisual()
    {
        if (!_grabbed && !_thrown)
        {
            Awaken(false);
            _state = SiriOrbState.Listening;
        }
    }

    private void TryIgnoreLocalPlayerCollisions()
    {
        if (_collider == null) return;
        try
        {
            GorillaTagger tagger = GorillaTagger.Instance;
            if (tagger == null) return;
            Collider body = tagger.bodyCollider;
            Collider head = tagger.headCollider;
            if (body != null) Physics.IgnoreCollision(_collider, body, true);
            if (head != null) Physics.IgnoreCollision(_collider, head, true);
        }
        catch { }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!_thrown) return;
        if (Time.realtimeSinceStartup - _lastImpactAt < 1.0f) return;
        float impact = collision.relativeVelocity.magnitude;
        if (impact < 0.8f) return;
        _lastImpactAt = Time.realtimeSinceStartup;
        Plugin.Instance?.ReactToImpact(impact);
    }

    private void OnDestroy()
    {
        if (_collider != null && _collider.material != null) Object.Destroy(_collider.material);
        if (_referenceFaceMaterial != null) Object.Destroy(_referenceFaceMaterial);
        if (_referenceTexture != null) Object.Destroy(_referenceTexture);
    }
}
