using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;

namespace HeySiri;

/// <summary>
/// Small Windows speech-recognition bridge used by the mod. Keeping it outside
/// Unity's Windows speech module avoids an extra Unity DLL dependency.
/// </summary>
internal sealed class SpeechBridge : IDisposable
{
    private readonly ConcurrentQueue<string> _results = new ConcurrentQueue<string>();
    private readonly ConcurrentQueue<string> _errors = new ConcurrentQueue<string>();
    private Process _process;

    public bool IsRunning
    {
        get
        {
            try { return _process != null && !_process.HasExited; }
            catch { return false; }
        }
    }

    public void Start()
    {
        Stop();

        const string script = @"
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$recognizer = New-Object System.Speech.Recognition.SpeechRecognitionEngine
$grammar = New-Object System.Speech.Recognition.DictationGrammar
$recognizer.LoadGrammar($grammar)
$recognizer.InitialSilenceTimeout = [TimeSpan]::FromSeconds(3.5)
$recognizer.BabbleTimeout = [TimeSpan]::FromSeconds(3.0)
$recognizer.EndSilenceTimeout = [TimeSpan]::FromMilliseconds(450)
$recognizer.EndSilenceTimeoutAmbiguous = [TimeSpan]::FromMilliseconds(700)
$recognizer.SetInputToDefaultAudioDevice()
[Console]::Out.WriteLine('__HEYSIRI_READY__')
[Console]::Out.Flush()
while ($true) {
    try {
        $result = $recognizer.Recognize([TimeSpan]::FromSeconds(7))
        if ($null -ne $result -and -not [String]::IsNullOrWhiteSpace($result.Text)) {
            [Console]::Out.WriteLine($result.Text)
            [Console]::Out.Flush()
        }
    }
    catch {
        [Console]::Error.WriteLine($_.Exception.Message)
        [Console]::Error.Flush()
        Start-Sleep -Milliseconds 250
    }
}
";

        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = "-NoLogo -NoProfile -NonInteractive -EncodedCommand " + encoded,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };

        _process = new Process { StartInfo = startInfo, EnableRaisingEvents = true };
        _process.OutputDataReceived += OnOutputDataReceived;
        _process.ErrorDataReceived += OnErrorDataReceived;

        if (!_process.Start())
            throw new InvalidOperationException("Windows speech helper could not be started.");

        _process.BeginOutputReadLine();
        _process.BeginErrorReadLine();
    }

    public bool TryDequeueResult(out string text)
    {
        return _results.TryDequeue(out text);
    }

    public bool TryDequeueError(out string text)
    {
        return _errors.TryDequeue(out text);
    }

    private void OnOutputDataReceived(object sender, DataReceivedEventArgs e)
    {
        string line = e.Data;
        if (string.IsNullOrWhiteSpace(line) || line == "__HEYSIRI_READY__") return;
        _results.Enqueue(line.Trim());
    }

    private void OnErrorDataReceived(object sender, DataReceivedEventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(e.Data)) _errors.Enqueue(e.Data.Trim());
    }

    public void Stop()
    {
        Process process = _process;
        _process = null;
        if (process == null) return;

        try
        {
            process.OutputDataReceived -= OnOutputDataReceived;
            process.ErrorDataReceived -= OnErrorDataReceived;
        }
        catch { }

        try
        {
            if (!process.HasExited) process.Kill();
        }
        catch { }

        try { process.Dispose(); } catch { }
    }

    public void Dispose()
    {
        Stop();
    }
}
