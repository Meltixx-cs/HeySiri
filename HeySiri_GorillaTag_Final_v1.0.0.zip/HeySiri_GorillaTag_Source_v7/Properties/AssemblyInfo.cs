using System.Reflection;

[assembly: AssemblyTitle("HeySiri")]
[assembly: AssemblyDescription("HeySiri voice assistant mod for Gorilla Tag")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HeySiri")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
