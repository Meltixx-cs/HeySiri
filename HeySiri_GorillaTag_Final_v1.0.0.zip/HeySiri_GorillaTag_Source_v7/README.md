# HeySiri for Gorilla Tag — v1.0.0

HeySiri is an unofficial Gorilla Tag voice companion powered by Groq. Say **“Hey Siri”** or press **H** on PC, then talk normally. Siri appears beside your view, answers out loud, shows optional subtitles, and can be grabbed and thrown.

This is a fan-made project and is not made by or affiliated with Apple.

## Final v1.0.0 changes

- The idle face now uses the supplied Siri reference art directly instead of trying to recreate it only with LineRenderers.
- The reference is embedded into the DLL and sits on a real 3D glass orb, so the front view matches the reference much more closely while the object still has depth in VR.
- Removed the old floating ambient rainbow ribbons/sparks that made the orb look like a generic color-changing ball.
- Talking now creates **audio-reactive bumps around the edge** of Siri like a circular sound waveform.
- The face stretches and breathes slightly with speech while the whole orb softly bobs with the voice.
- Listening, thinking, talking, wake, recall, grab, throw, and idle states all keep separate motion.
- Added three personalities: **Normal**, **Evil**, and **Rizzy**.
- Added mode-specific wake greetings.
- Added a cleaner F2 panel with dedicated **NORMAL / EVIL / RIZZY** buttons.
- Added Siri text/subtitle toggle.
- Kept smooth PC mouse grabbing/throwing and VR grip throwing.
- Built-in voice/text commands were expanded.

## Siri modes

### Normal

Normal conversational Siri. Helpful, casual, and quick.

### Evil

Very rude, sarcastic, vulgar, and insulting while still answering the question. It swears often and can roast the user hard. The prompt intentionally avoids protected-class slurs, self-harm encouragement, and credible real-world threats.

### Rizzy

Playful, confident, compliment-heavy Siri with cheesy pickup-line energy. It uses things like “gorgeous,” “cutie,” and “babe,” while staying non-explicit and still answering the actual question.

When you say only **“Hey Siri”**, the wake response changes with the current mode before Siri starts listening.

## PC controls

- **H** — wake Siri
- **F2** — open/close control panel
- **B** — recall Siri
- **Right-click + hold on Siri** — grab
- **Move mouse** — drag
- **Release right-click** — throw
- **Enter** in the F2 text box — send typed message
- Say **“Hey Siri”** — voice wake

## VR controls

- Say **“Hey Siri”** — wake Siri
- Hold either **grip** near Siri — grab
- Release grip while moving — throw
- Right controller **B / secondary button** — recall

Keyboard controls can still be used while playing PCVR.

## Built-in commands

Type these in F2 or say them while Siri is listening:

- `normal siri`
- `evil siri`
- `rizzy siri`
- `what mode are you`
- `recall siri`
- `show siri`
- `hide siri`
- `mute siri`
- `unmute siri`
- `siri text on`
- `siri text off`
- `clear chat`
- `commands`

## Groq setup

Create your own Groq API key and launch Gorilla Tag once. Then open:

```text
Gorilla Tag\BepInEx\config\org.heysiri.gorillatag.cfg
```

Set:

```ini
[AI]
GroqApiKey = YOUR_KEY_HERE
SiriMode = Normal
```

Do not upload your API key to GitHub or ship your personal key inside a public build.

## Orb asset

The exact idle reference used by this source is:

```text
Assets\SiriIdle.png
```

It is compiled into `HeySiri.dll` as an embedded resource. If you replace that PNG with another transparent square image and rebuild, the 3D orb will use the new face without needing to rewrite the visual code.

For a public release, make sure you have the rights to distribute any artwork you include. An original Siri-inspired image is safer branding-wise than shipping Apple artwork directly.

## Building

Run:

```text
BUILD.bat
```

or:

```powershell
dotnet build HeySiri.csproj -c Release
```

The project expects Gorilla Tag to be in the default Steam location unless you override `GorillaTagDir`.
