# HeySiri source notes — v1.0.0

Final source pass focused on the orb appearance, persona modes, and simple controls.

## Visuals

`Assets/SiriIdle.png` is embedded into the plugin and rendered on the front of the 3D orb. This fixes the main problem with the previous code-generated petal version: the idle orb now uses the supplied reference directly instead of approximating the Siri artwork with generic rainbow geometry.

The dark sphere behind it gives the object physical depth. The two edge rings remain generated at runtime. While speech audio is playing, their vertices move radially from the real audio envelope to create circular sound-wave bumps.

## Modes

The config setting is now:

```ini
[AI]
SiriMode = Normal
```

Supported values are `Normal`, `Evil`, and `Rizzy`. The F2 panel and local voice/text commands update this setting.

## Public build note

The included reference image came from the supplied project reference. If this is distributed publicly, verify that the artwork can legally be redistributed, or replace `Assets/SiriIdle.png` with original artwork before release.
